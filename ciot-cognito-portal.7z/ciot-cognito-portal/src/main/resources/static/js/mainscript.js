var myapp =angular.module('myApp', []);


myapp.controller('myWelcomeController',function($scope,$http,$window) {
	$scope.displayerrorwelcome=true;
	$scope.servedUserName=window.localStorage.getItem("servedUserName");
	$scope.servedToken=window.localStorage.getItem("servedToken");
	
	if(!$scope.servedUserName || !$scope.servedToken) // if a is negative,undefined,null,empty value then...
	{
		$scope.servicestatus="No service requested!";
	    $scope.responsestyle = {
			"padding": "14px 20px",
	        "color" : "black",
	        "background-color" : "yellow",
	        "font-weight": "normal",
	    }
	
	}else{
	    $scope.responsestyle = {
			"padding": "14px 20px",
	        "color" : "white",
	        "background-color" : "#4CAF50",
	        "font-weight": "normal",
	    }
	    $scope.servicestatus="Hello "+ $scope.servedUserName+"."
		window.localStorage.removeItem("servedUserName");
		window.localStorage.removeItem("servedToken");
	}
	
	
	
	
	$scope.cognitoLogout = function() {
		$scope.errors=[];
		var json ={"userName":$scope.servedUserName,"token":$scope.servedToken};
		$http({
	        method : "POST",
	        url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/pooluser/logoutPoolUser/",
	        data : angular.toJson(json),
	        headers : {
	        	'Content-Type' : 'application/json'
	        }
	    }).then(function successCallback(response) {
        	
        	if(response.data.serviceStatus.code!='0'){
        		$scope.servicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
        		$scope.displayerrorwelcome=false;
        		$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
        		var array=response.data.errorDetails;
            		angular.forEach(array, function(value, key) {
            				$scope.errors.push(value);
            		});
        		
        	}else{
        		var array=response.data.awsResponseObject;
        		angular.forEach(array, function(value, key) {
        			window.localStorage.setItem("loggedOutResponse",value);
    		    });
        		
                $window.location='/index.html';
        	}
        }, function errorCallback(response) {
        	$scope.responsestyle = {
    		        "color" : "white",
    		        "background-color" : "red",
    		        "font-weight": "normal",
    		    }
        	$scope.servicestatus="Hi, There is error in server. Please contact the admin."
	    });
	  };
	 
});


myapp.controller('myWelcomeGoogleController',function($scope,$http,$window) {
$scope.displayerrorwelcome=true;
$scope.displayservedUserName=true;		
$scope.servedIdentityId="";
$scope.getQuery = function(){
	    var url = location.href;
	    var qs = url.substring(url.indexOf('?') + 1).split('&');
	    for(var i = 0, result = {}; i < qs.length; i++){
	        qs[i] = qs[i].split('=');
	        result[qs[i][0]] = qs[i][1];
	    }
	    return result;
};

$scope.loginGoogle = function(){
	$scope.urlData  = $scope.getQuery();
	if(!$scope.urlData.code) // if a is negative,undefined,null,empty value then...
	{
		$scope.servicestatus="No service requested!";
	    $scope.responsestyle = {
			"padding": "14px 20px",
	        "color" : "black",
	        "background-color" : "yellow",
	        "font-weight": "normal",
	    }
	}else{
		
		$http({
        method : "GET",
        url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/federateduser/googleuser/exchangecode?code="+$scope.urlData.code,
        data : angular.toJson($scope.form),
        headers : {
        	'Content-Type' : 'application/json'
        }
       }).then(function successCallback(response) {
    	  
    	  
    	$scope.servicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
    	if(response.data.serviceStatus.code!='0'){
    		$scope.errors=[];
    		$scope.displayerrorwelcome=false;
    		$scope.displayservedUserName=true;	
    		$scope.responsestyle = {
    		        "color" : "white",
    		        "background-color" : "red",
    		        "font-weight": "normal",
    		    }
    		var array=response.data.errorDetails;
    		
        		angular.forEach(array, function(value, key) {
        			
        				$scope.errors.push(value);
        	       
        	
    		});
    		
    		
    		
    	}else{
    		
    		$scope.displayerrorwelcome=true;
    		$scope.displayservedUserName=false;
    		var array=response.data.awsResponseObject;
    		
    		 $scope.responsestyle = {
    	   				"padding": "14px 20px",
    	   		        "color" : "white",
    	   		        "background-color" : "#4CAF50",
    	   		        "font-weight": "normal",
    	      }
    		$scope.displayerrorwelcome=true;
     		$scope.displayservedUserName=false;		  
    		angular.forEach(array, function(value, key) {
    			$scope.servedUserName="Hello, your Google IdentityId is "+value+".";
    			$scope.servedIdentityId=value;
		    });
    		
    	}
    }, function errorCallback(response) {
    	$scope.responsestyle = {
		        "color" : "white",
		        "background-color" : "red",
		        "font-weight": "normal",
		    }
    	$scope.servicestatus="Hi, There is error in server. Please contact the admin."
    });
	}
};

$scope.loginGoogle();


$scope.googleLogout=function(){
	
	
	if(!$scope.servedIdentityId){
		$scope.responsestyle = {
		        "color" : "white",
		        "background-color" : "red",
		        "font-weight": "normal",
		    }
		$scope.servicestatus="No user is logged in.";
	}else{
		$scope.errors=[];
		$http({
	        method : "DELETE",
	        url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/federateduser/delete/identity/"+$scope.servedIdentityId,
	        data : angular.toJson($scope.form),
	        headers : {
	        	'Content-Type' : 'application/json'
	        }
	    }).then(function successCallback(response) {
	    	$scope.servicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
	    	if(response.data.serviceStatus.code!='0'){
	    		$scope.displayerrorwelcome=false;
	    		$scope.displayservedUserName=true;	
	    		$scope.responsestyle = {
	    		        "color" : "white",
	    		        "background-color" : "red",
	    		        "font-weight": "normal",
	    		    }
	    		var array=response.data.errorDetails;
	        		angular.forEach(array, function(value, key) {
	        				$scope.errors.push(value);
	        		});
	    		
	    	}else{
	    		var array=response.data.awsResponseObject;
	    		angular.forEach(array, function(value, key) {
	    			window.localStorage.setItem("federatedloggedOutResponse",key+" "+value);
			    });
	    		
	            $window.location='/index.html';
	    	}
	    }, function errorCallback(response) {
	    	$scope.responsestyle = {
    		        "color" : "white",
    		        "background-color" : "red",
    		        "font-weight": "normal",
    		    }
	    	$scope.servicestatus="Hi, There is error in server. Please contact the admin."
	    });
	}
};

	
});


myapp.controller('myWelcomeFacebookController',function($scope,$http,$window) {
	$scope.displayerrorwelcome=true;
	$scope.displayservedUserName=true;		
	$scope.servedIdentityId="";	
	
$scope.getQuery = function(){
	    var url = location.href;
	    var qs = url.substring(url.indexOf('?') + 1).split('&');
	    for(var i = 0, result = {}; i < qs.length; i++){
	        qs[i] = qs[i].split('=');
	        result[qs[i][0]] = qs[i][1];
	    }
	    return result;
};

$scope.loginFacebook = function(){
	$scope.urlData  = $scope.getQuery();
	if(!$scope.urlData.code) // if a is negative,undefined,null,empty value then...
	{
		$scope.servicestatus="No service requested!";
	    $scope.responsestyle = {
			"padding": "14px 20px",
	        "color" : "black",
	        "background-color" : "yellow",
	        "font-weight": "normal",
	    }
	}else{
		 $http({
		        method : "GET",
		        url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/federateduser/facebookuser/exchangecode?code="+$scope.urlData.code,
		        data : angular.toJson($scope.form),
		        headers : {
		        	'Content-Type' : 'application/json'
		        }
		    }).then(function successCallback(response) {
		    	
		    	
		    	$scope.servicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
		    	if(response.data.serviceStatus.code!='0'){
		    		$scope.errors=[];
		    		$scope.displayerrorwelcome=false;
		    		$scope.displayservedUserName=true;	
		    		$scope.responsestyle = {
		    		        "color" : "white",
		    		        "background-color" : "red",
		    		        "font-weight": "normal",
		    		    }
		    		var array=response.data.errorDetails;
		    		
		        		angular.forEach(array, function(value, key) {
		        			
		        				$scope.errors.push(value);
		        	       
		        	
		    		});
		    		
		    		
		    		
		    	}else{
		    		var array=response.data.awsResponseObject;
		    		$scope.displayerrorwelcome=true;
		    		$scope.displayservedUserName=false;
		    		 $scope.responsestyle = {
		    	   				"padding": "14px 20px",
		    	   		        "color" : "white",
		    	   		        "background-color" : "#4CAF50",
		    	   		        "font-weight": "normal",
		    	      }
		    		angular.forEach(array, function(value, key) {
		    			$scope.servedUserName="Hello, your Facebook IdentityId is "+value+".";
		    			$scope.servedIdentityId=value;

				    });
		    	}
		    }, function errorCallback(response) {
		    	$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
		    	$scope.servicestatus="Hi, There is error in server. Please contact the admin."
		    });
	}
};

$scope.loginFacebook();


$scope.facebookLogout=function(){
	
	
	if(!$scope.servedIdentityId){
		$scope.responsestyle = {
		        "color" : "white",
		        "background-color" : "red",
		        "font-weight": "normal",
		    }
		$scope.servicestatus="No user is logged in.";
	}else{
		$scope.errors=[];
		$http({
	        method : "DELETE",
	        url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/federateduser/delete/identity/"+$scope.servedIdentityId,
	        data : angular.toJson($scope.form),
	        headers : {
	        	'Content-Type' : 'application/json'
	        }
	    }).then(function successCallback(response) {
	    	
	    	if(response.data.serviceStatus.code!='0'){
	    		$scope.servicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
	    		var array=response.data.errorDetails;
	        		angular.forEach(array, function(value, key) {
	        				$scope.errors.push(value);
	        		});
	    		
	    	}else{
	    		var array=response.data.awsResponseObject;
	    		angular.forEach(array, function(value, key) {
	    			window.localStorage.setItem("federatedloggedOutResponse",key+" "+value);
			    });
	    		
	            $window.location='/index.html';
	    	}
	    }, function errorCallback(response) {
	    	$scope.responsestyle = {
    		        "color" : "white",
    		        "background-color" : "red",
    		        "font-weight": "normal",
    		    }
	    	$scope.servicestatus="Hi, There is error in server. Please contact the admin."
	    });
	}
};

});






myapp.controller('myAppController',function($scope,$http,$window) {
	$scope.servicestatus="No service requested!";
	$scope.federatedservicestatus="No service requested!";
	$scope.iamservicestatus="No service requested!";
	$scope.responsestyle = {
			"padding": "14px 20px",
	        "color" : "black",
	        "background-color" : "yellow",
	        "font-weight": "normal",
	    }
	$scope.controlDisplay=function(value){
		if(value==1){
			$scope.showhome=true;
			$scope.showcognitopool=false;
			$scope.showfederatedpool=false;
			$scope.showiam=false;
		}else if (value==2){
			$scope.showhome=false;
			$scope.showcognitopool=true;
			$scope.showfederatedpool=false;
			$scope.showiam=false;
		}else if(value==3){
			$scope.showhome=false;
			$scope.showcognitopool=false;
			$scope.showfederatedpool=true;
			$scope.showiam=false;
			
		}else if(value==4){
			$scope.showhome=false;
			$scope.showcognitopool=false;
			$scope.showfederatedpool=false;
			$scope.showiam=true;
		}
		
	};
	
	
	$scope.controlDisplay(1);
	
	$scope.commonresponse=[];
	$scope.federatedcommonresponse=[];
	$scope.iamcommonresponse=[];
	var cognitoPoolUserResponse=window.localStorage.getItem("loggedOutResponse");
	var cognitoFederatedUserResponse=window.localStorage.getItem("federatedloggedOutResponse");
	var iamUserResponse=window.localStorage.getItem("iamloggedOutResponse");
	
	
	
	
	
	if(!cognitoPoolUserResponse) // if a is negative,undefined,null,empty value then...
	{
		$scope.displayerror=true;
		$scope.displayresponse=true;
	}
	else {
		
		$scope.controlDisplay(2);
		$scope.servicestatus="Success!";
		$scope.responsestyle = {
		        "color" : "white",
		        "background-color" : "#4CAF50",
		        "font-weight": "normal",
		    }
		//$scope.commonresponse.push(cognitoPoolUserResponse);
		$scope.commonresponse.push("You have been Logged out successfully.");
		window.localStorage.removeItem("loggedOutResponse");
		$scope.displayerror=false;
		$scope.displayresponse=true;
	}
	
	if(!cognitoFederatedUserResponse) // if a is negative,undefined,null,empty value then...
	{
		$scope.displayfederatederror=true;
		$scope.displayfederatedresponse=true;
	}
	else {
		$scope.controlDisplay(3);
		$scope.federatedservicestatus="Success!";
		$scope.responsestyle = {
		        "color" : "white",
		        "background-color" : "#4CAF50",
		        "font-weight": "normal",
		    }
		//$scope.federatedcommonresponse.push(cognitoFederatedUserResponse);
		$scope.federatedcommonresponse.push("You have been Logged out successfully.");
		window.localStorage.removeItem("federatedloggedOutResponse");
		$scope.displayfederatederror=false;
		$scope.displayfederatedresponse=true;
	}
	
	if(!iamUserResponse) // if a is negative,undefined,null,empty value then...
	{
		$scope.displayiamresponse=true;
		$scope.displayiamerror=true;
	}
	else {
		$scope.controlDisplay(4);
		$scope.iamservicestatus="Success!";
		$scope.responsestyle = {
		        "color" : "white",
		        "background-color" : "#4CAF50",
		        "font-weight": "normal",
		    }
		//$scope.iamcommonresponse.push(iamUserResponse);
		$scope.iamcommonresponse.push("You have been Logged out successfully.");
		window.localStorage.removeItem("iamloggedOutResponse");
		$scope.displayiamerror=true;
		$scope.displayiamresponse=false;
	}
	
	
	
	
	$scope.retrieveUser= function(){
		$scope.records=[];
		$scope.errors=[];
        $http({
            method : "GET",
            url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/pooluser/retrieveuser/" + $scope.username,
            data : angular.toJson($scope.form),
            headers : {
            	'Content-Type' : 'application/json'
            }
        }).then(function successCallback(response) {
        	
        	
        	$scope.servicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
        	if(response.data.serviceStatus.code!='0'){
        		$scope.displayerror=true;
        		$scope.displayresponse=false;
        		$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
        		var array=response.data.errorDetails;
        		
            		angular.forEach(array, function(value, key) {
            			
            				$scope.errors.push(value);
            	       
            	
        		});
        		
        		
        		
        	}else{
        		$scope.displayerror=false;
        		$scope.displayresponse=true;
        		$scope.responsestyle = {
						
        		        "color" : "white",
        		        "background-color" : "#4CAF50",
        		        "font-weight": "normal",
        		    }
        		var array=response.data.awsResponseObject;
        		angular.forEach(array, function(value, key) {
        			angular.forEach(value,function(v1,k1){
        				$scope.records.push(v1);
        				
        	        });
        		});
        	}
        	$scope.password="";
    		$scope.username="";
        }, function errorCallback(response) {
        	$scope.responsestyle = {
    		        "color" : "white",
    		        "background-color" : "red",
    		        "font-weight": "normal",
    		    }
        	$scope.servicestatus="Hi, There is error in server. Please contact the admin."
        });
        
	};
	
	
	
	
	
	
	
	
	
	$scope.testAction= function(){
		$scope.federatedrecords=[];
		$scope.federatederrors=[];
		
		
        $http({
            method : "GET",
            url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/federateduser/test",
            data : angular.toJson($scope.form),
            headers : {
            	'Content-Type' : 'application/json'
            }
        }).then(function successCallback(response) {
        	
        	
        	$scope.federatedservicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
        	if(response.data.serviceStatus.code!='0'){
        		$scope.displayfederatederror=true;
        		$scope.displayfederatedresponse=false;
        		$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
        		var array=response.data.errorDetails;
        		
            		angular.forEach(array, function(value, key) {
            			
            				$scope.errors.push(value);
            	       
            		});
        		
        		
        		
        	}else{
        		$scope.displayfederatederror=false;
        		$scope.displayfederatedresponse=true;
        		$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "#4CAF50",
        		        "font-weight": "normal",
        		    }
        		var array=response.data.awsResponseObject;
        		angular.forEach(array, function(value, key) {
        			
        				$scope.federatedcommonresponse.push(value);
        
        		});
        	}
        }, function errorCallback(response) {
        	
        	$scope.responsestyle = {
    		        "color" : "white",
    		        "background-color" : "red",
    		        "font-weight": "normal",
    		    }
        	$scope.federatedservicestatus="Hi, There is error in server. Please contact the admin."
        });
        
	};
	
	$scope.cognitoLogin = function() {
		$scope.records=[];
		$scope.errors=[];
		var json ={"password":$scope.password,"userName":$scope.username};

		$http({
	        method : "POST",
	        url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/pooluser/loginPoolUser/",
	        data : angular.toJson(json),
	        headers : {
	        	'Content-Type' : 'application/json'
	        }
	    }).then(function successCallback(response) {
        	
        	
        	$scope.servicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
        	if(response.data.serviceStatus.code!='0'){
        		$scope.displayerror=true;
        		$scope.displayresponse=false;
        		$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
        		var array=response.data.errorDetails;
        		
            		angular.forEach(array, function(value, key) {
            			
            				$scope.errors.push(value);
            				
            		});
        		
        		
        		
        	}else{
        		$scope.displayerror=false;
        		$scope.displayresponse=true;
        		var array=response.data.awsResponseObject;
        		window.localStorage.setItem("servedUserName",array.userDetails.username);
        		window.localStorage.setItem("servedToken",array.accesstoken);
                $window.location='/welcome.html';
        		
        		
        	}
        	$scope.password="";
    		$scope.username="";
        }, function errorCallback(response) {
        	$scope.responsestyle = {
    		        "color" : "white",
    		        "background-color" : "red",
    		        "font-weight": "normal",
    		    }
        	$scope.servicestatus="Hi, There is error in server. Please contact the admin."
	    });
	  };
	  
	  
	  
	  
	  //google login
	  
	  $scope.googleLogin = function() {
			$scope.federatedrecords=[];
			$scope.federatederrors=[];
			
			
	        $http({
	            method : "GET",
	            url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/federateduser/googleuser/loginurl",
	            data : angular.toJson($scope.form),
	            headers : {
	            	'Content-Type' : 'application/json'
	            }
	        }).then(function successCallback(response) {
	        	
	        	
	        	$scope.federatedservicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
	        	if(response.data.serviceStatus.code!='0'){
	        		$scope.displayfederatederror=true;
	        		$scope.displayfederatedresponse=false;
	        		$scope.responsestyle = {
	        		        "color" : "white",
	        		        "background-color" : "red",
	        		        "font-weight": "normal",
	        		    }
	        		var array=response.data.errorDetails;
	        		
	            		angular.forEach(array, function(value, key) {
	            			
	            				$scope.errors.push(value);
	            	       
	            		});
	        		
	        		
	        		
	        	}else{
	        		$scope.displayfederatederror=false;
	        		$scope.displayfederatedresponse=true;
	        		var array=response.data.awsResponseObject;
	        		angular.forEach(array, function(value, key) {
	        			 $window.location=value;
	        
	        		});
	        	}
	        }, function errorCallback(response) {
	        	$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
	        	
	        	$scope.federatedservicestatus="Hi, There is error in server. Please contact the admin."
	        });
	        
		};
	  
	  
	  
	  
	  //facebook login
	  
		$scope.facebookLogin = function() {
			$scope.federatedrecords=[];
			$scope.federatederrors=[];
			
			
	        $http({
	            method : "GET",
	            url : "http://ec2-34-236-93-73.compute-1.amazonaws.com:8990/cognito/federateduser/facebookuser/loginurl",
	            data : angular.toJson($scope.form),
	            headers : {
	            	'Content-Type' : 'application/json'
	            }
	        }).then(function successCallback(response) {
	        	
	        	
	        	$scope.federatedservicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
	        	if(response.data.serviceStatus.code!='0'){
	        		$scope.displayfederatederror=true;
	        		$scope.displayfederatedresponse=false;
	        		$scope.responsestyle = {
	        		        "color" : "white",
	        		        "background-color" : "red",
	        		        "font-weight": "normal",
	        		    }
	        		var array=response.data.errorDetails;
	        		
	            		angular.forEach(array, function(value, key) {
	            			
	            				$scope.errors.push(value);
	            	       
	            		});
	        		
	        		
	        		
	        	}else{
	        		$scope.displayfederatederror=false;
	        		$scope.displayfederatedresponse=true;
	        		var array=response.data.awsResponseObject;
	        		angular.forEach(array, function(value, key) {
	        			$window.location=value;
	        		});
	        	}
	        }, function errorCallback(response) {
	        	$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
	        	
	        	$scope.federatedservicestatus="Hi, There is error in server. Please contact the admin."
	        });
	        
		};
	  
	  
	  //googleIamLogin
		
		$scope.googleIamLogin=function() {
			$scope.iamrecords=[];
			$scope.iamcommonresponse=[];
			
			
	        $http({
	            method : "GET",
	            url : "http://10.203.180.164:2020/google/loginurl",
	            data : angular.toJson($scope.form),
	            headers : {
	            	'Content-Type' : 'application/json'
	            }
	        }).then(function successCallback(response) {
	        	
	        	
	        	$scope.iamservicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
	        	if(response.data.serviceStatus.code!='0'){
	        		$scope.displayiamerror=false;
	        		$scope.displayiamresponse=true;
	        		$scope.responsestyle = {
	        		        "color" : "white",
	        		        "background-color" : "red",
	        		        "font-weight": "normal",
	        		    }
	        		var array=response.data.errorDetails;
	        		
	            		angular.forEach(array, function(value, key) {
	            			
	            				$scope.errors.push(value);
	            	       
	            		});
	        		
	        		
	        		
	        	}else{
	        		$scope.displayiamerror=true;
	        		$scope.displayiamresponse=false;
	        		var loginUrl=response.data.loginUrl;
	        		$window.location=loginUrl;
	        	}
	        }, function errorCallback(response) {
	        	$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
	        	
	        	$scope.iamservicestatus="Hi, There is error in server. Please contact the admin."
	        });
	        
		
			
		};
		
		$scope.fecebookIamLogin=function() {
			$scope.iamrecords=[];
			$scope.iamcommonresponse=[];
			
			
	        $http({
	            method : "GET",
	            url : "http://10.203.180.164:2020/facebook/loginurl",
	            data : angular.toJson($scope.form),
	            headers : {
	            	'Content-Type' : 'application/json'
	            }
	        }).then(function successCallback(response) {
	        	
	        	
	        	$scope.iamservicestatus="Service Status: " +response.data.serviceStatus.code+" - "+response.data.serviceStatus.description;
	        	if(response.data.serviceStatus.code!='0'){
	        		$scope.displayiamerror=false;
	        		$scope.displayiamresponse=true;
	        		$scope.responsestyle = {
	        		        "color" : "white",
	        		        "background-color" : "red",
	        		        "font-weight": "normal",
	        		    }
	        		var array=response.data.errorDetails;
	        		
	            		angular.forEach(array, function(value, key) {
	            			
	            				$scope.errors.push(value);
	            	       
	            		});
	        		
	        		
	        		
	        	}else{
	        		$scope.displayiamerror=true;
	        		$scope.displayiamresponse=false;
	        		var loginUrl=response.data.loginUrl;
	        		$window.location=loginUrl;
	        	}
	        }, function errorCallback(response) {
	        	$scope.responsestyle = {
        		        "color" : "white",
        		        "background-color" : "red",
        		        "font-weight": "normal",
        		    }
	        	
	        	$scope.iamservicestatus="Hi, There is error in server. Please contact the admin."
	        });
	        
		
			
		};
	  
	

});



