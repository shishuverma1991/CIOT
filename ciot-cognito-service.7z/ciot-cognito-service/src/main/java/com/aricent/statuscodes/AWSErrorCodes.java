package com.aricent.statuscodes;





public enum AWSErrorCodes
{
  EXCEPTION("_EXC_001"), 
  NULL_VALUE_EXCEPTION("_ERR_002"), 
  SDK_CLIENT_EXCEPTION("_EXC_003"), 
  NUMBER_FORMAT("_ERR_004"), 
  
  SERVICE_EXCEPTION("_EXC_005"), 
  IAM_MGMT_EXCEPTION("_EXC_006"), 
  COGNITO_IDENTITY_PROVIDER("_ERR_007"), 
  
  RESOURCE_NOT_FOUND("_ERR_008"), 
  INVALID_PARAMETER_EXCEPTION("_ERR_009"), 
  USER_NOT_FOUND("_ERR_010"), 
  CHALLENGE_EXCEPTION("_ERR_011"), 
  VALIDATION_ERROR("_ERR_012"), 
  NOT_A_VALID_TOKEN("_ERR_013"), 
  
  CONNECT_EXCEPTION("_ERR_014"), 
  NOT_AUTHORIZED_USER("_ERR_015");
  
  private final String errorCode;
  
  private AWSErrorCodes(String errorCode)
  {
    this.errorCode = errorCode;
  }
  



  public String getErrorCode()
  {
    return errorCode;
  }
}
