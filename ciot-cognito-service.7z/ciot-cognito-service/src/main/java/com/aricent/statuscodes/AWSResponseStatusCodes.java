package com.aricent.statuscodes;

import java.math.BigInteger;








public enum AWSResponseStatusCodes
{
  SUCCESS(BigInteger.valueOf(0L)), 
  VALIDATIONFAILURE(BigInteger.valueOf(1L)), 
  FAILURE(BigInteger.valueOf(2L));
  
  private final BigInteger statusCode;
  
  private AWSResponseStatusCodes(BigInteger statusCode)
  {
    this.statusCode = statusCode;
  }
  



  public BigInteger getStatusCode()
  {
    return statusCode;
  }
  

  public static AWSResponseStatusCodes valueOfResType(BigInteger type)
  {
    for (AWSResponseStatusCodes stat : values())
    {
      if (stat.getStatusCode().equals(type))
      {
        return stat;
      }
    }
    


    return null;
  }
}
