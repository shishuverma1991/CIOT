package com.aricent.ciot.service;

import com.aricent.iot.common.utils.LogUtil;
import org.springframework.social.facebook.connect.FacebookConnectionFactory;
import org.springframework.social.oauth2.AccessGrant;
import org.springframework.social.oauth2.OAuth2Operations;
import org.springframework.social.oauth2.OAuth2Parameters;
import org.springframework.stereotype.Service;









@Service
public class FacebookTokenGenerator
{
  private String OAUTH2_CLIENT_ID;
  private String OAUTH2_CLIENT_SECRET;
  private String OAUTH2_SCOPE;
  
  public FacebookTokenGenerator() {}
  
  public String getFacebookLoginUrl(AmazonCognitoIdentityGenerator amazonCognitoIdentityGenerator)
  {
    LogUtil.info("FacebookTokenGenerator", "getFacebookLoginUrl--START");
    OAUTH2_CLIENT_ID = amazonCognitoIdentityGenerator.get_facebookClientId();
    OAUTH2_CLIENT_SECRET = amazonCognitoIdentityGenerator.get_facebookSecretId();
    OAUTH2_SCOPE = amazonCognitoIdentityGenerator.get_facebookScope();
    
    FacebookConnectionFactory connectionFactory = getFacebookConnectionFactory();
    OAuth2Operations oauthOperations = connectionFactory.getOAuthOperations();
    OAuth2Parameters params = new OAuth2Parameters();
    params.setRedirectUri(amazonCognitoIdentityGenerator.get_facebookLoginRedirectUri());
    params.setScope(OAUTH2_SCOPE);
    LogUtil.info("FacebookTokenGenerator", "getFacebookLoginUrl--END");
    return oauthOperations.buildAuthorizeUrl(params);
  }
  
  private FacebookConnectionFactory getFacebookConnectionFactory() {
    FacebookConnectionFactory facebookConnectionFactory = new FacebookConnectionFactory(OAUTH2_CLIENT_ID, OAUTH2_CLIENT_SECRET);
    return facebookConnectionFactory;
  }
  




  public String getTokenFromCode(String code, AmazonCognitoIdentityGenerator amazonCognitoIdentityGenerator)
  {
    LogUtil.info("FacebookTokenGenerator", "getTokenFromCode--START");
    FacebookConnectionFactory connectionFactory = getFacebookConnectionFactory();
    AccessGrant accessGrant = connectionFactory.getOAuthOperations().exchangeForAccess(code, amazonCognitoIdentityGenerator.get_facebookLoginRedirectUri(), null);
    String accessToken = accessGrant.getAccessToken();
    LogUtil.info("FacebookTokenGenerator", "getTokenFromCode--END");
    return accessToken;
  }
}
