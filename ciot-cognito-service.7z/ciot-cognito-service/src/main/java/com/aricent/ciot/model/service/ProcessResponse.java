package com.aricent.ciot.model.service;

import com.aricent.iot.common.model.ServiceStatus;
import com.aricent.statuscodes.AWSResponseStatusCodes;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;







@Service
public class ProcessResponse
{
  private Map<String, Object> responseMap;
  
  public ProcessResponse() {}
  
  public void createOrCleanMap()
  {
    if (responseMap != null) {
      responseMap.clear();
    } else {
      responseMap = new HashMap();
    }
  }
  
  public void setValues(String key, Object value) {
    responseMap.put(key, value);
  }
  
  public Map<String, Object> getResponseMap() {
    return responseMap;
  }
  
  public ServiceStatus getServiceStatus(BigInteger statusCode) {
    ServiceStatus serviceStatus = new ServiceStatus();
    serviceStatus.setCode(statusCode.toString());
    serviceStatus.setDescription(AWSResponseStatusCodes.valueOfResType(statusCode).toString());
    return serviceStatus;
  }
}
