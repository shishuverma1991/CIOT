package com.aricent.ciot.service;

import java.math.BigInteger;
import java.net.ConnectException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;

import com.amazonaws.SdkClientException;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentity;
import com.amazonaws.services.cognitoidentity.model.DeleteIdentitiesRequest;
import com.amazonaws.services.cognitoidentity.model.DeleteIdentitiesResult;
import com.amazonaws.services.cognitoidentity.model.GetIdRequest;
import com.amazonaws.services.cognitoidentity.model.GetIdResult;
import com.amazonaws.services.cognitoidp.model.AWSCognitoIdentityProviderException;
import com.amazonaws.services.cognitoidp.model.ChallengeNameType;
import com.amazonaws.services.cognitoidp.model.InvalidParameterException;
import com.amazonaws.services.cognitoidp.model.NotAuthorizedException;
import com.amazonaws.services.cognitoidp.model.ResourceNotFoundException;
import com.amazonaws.services.cognitoidp.model.UserNotFoundException;
import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.ciot.helper.StringUtils;
import com.aricent.ciot.model.CognitoGetRequest;
import com.aricent.ciot.model.CognitoResponse;
import com.aricent.ciot.model.CognitoUserRequest;
import com.aricent.ciot.model.service.ProcessResponse;
import com.aricent.iot.common.model.AWSBaseRequest;
import com.aricent.iot.common.model.ServiceStatus;
import com.aricent.iot.common.utils.LogUtil;
import com.aricent.statuscodes.AWSErrorCodes;

@Service
public class FederatedUserService
{
  @Autowired
  private ProcessResponse processResponse;
  @Autowired
  private TokenGenerator tokenGenerator;
  @Autowired
  private GoogleTokenGenerator googleTokenGenerator;
  @Autowired
  private AmazonCognitoIdentityGenerator amazonCognitoIdentityGenerator;
  @Autowired
  private FacebookTokenGenerator facebookTokenGenerater;
  private CognitoResponse cognitoResponse = null;
  
  public FederatedUserService() {}
  
  public AWSBaseRequest prepareCognitoPoolUserGetRequest(String name, String value) { LogUtil.serviceInfo("FederatedUserService", "prepareCognitoPoolUserGetRequest--START");
    
    CognitoGetRequest cognitoGetRequest = new CognitoGetRequest("System", amazonCognitoIdentityGenerator.getSpringApplicationName(), StringUtils.getCurrentDate(), value, name);
    LogUtil.serviceInfo("FederatedUserService", "prepareCognitoPoolUserGetRequest--END");
    return cognitoGetRequest;
  }
  
  public AWSBaseRequest prepareCognitoUserRequest(CognitoUserRequest cognitoUserRequest) {
    LogUtil.serviceInfo("FederatedUserService", "prepareCognitoUserRequest--START");
    cognitoUserRequest.setInvokedBy("System");
    cognitoUserRequest.setWebServiceId(amazonCognitoIdentityGenerator.getSpringApplicationName());
    cognitoUserRequest.setDate(StringUtils.getCurrentDate());
    LogUtil.serviceInfo("FederatedUserService", "prepareCognitoUserRequest--END");
    return cognitoUserRequest;
  }
  
  public CognitoResponse servecognitoPoolUsertIdentity(AWSBaseRequest awsBaseRequest) throws CognitoServiceException {
    LogUtil.serviceInfo("FederatedUserService", "servecognitoPoolUsertIdentity--START");
    if ((awsBaseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest cognitoUserRequest = (CognitoUserRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        cognitoResponse = new CognitoResponse();
        String token = tokenGenerator.generateToken(cognitoUserRequest);
        if (token != null) {
          if (token.equals(ChallengeNameType.NEW_PASSWORD_REQUIRED.name()))
          {
            processResponse.setValues("Challenge Name", ChallengeNameType.NEW_PASSWORD_REQUIRED.name());
            
            ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(200L));
            cognitoResponse.setServiceStatus(serviceStatus);
            cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
          }
          else {
            AmazonCognitoIdentity getawsclient = amazonCognitoIdentityGenerator.getawsclient();
            
            GetIdRequest getIdRequest = new GetIdRequest();
            getIdRequest
              .setIdentityPoolId(amazonCognitoIdentityGenerator.get_amazonCognitoFederatedPoolId());
            Map<String, String> logins = new HashMap();
            logins.put("cognito-idp." + amazonCognitoIdentityGenerator.getAwsregion() + ".amazonaws.com/" + amazonCognitoIdentityGenerator
              .get_cognitoUserpoolId(), token);
            getIdRequest.setLogins(logins);
            
            GetIdResult idresult = getawsclient.getId(getIdRequest);
            
            BigInteger statusCode = BigInteger.valueOf(idresult.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
            
            processResponse.setValues("Cognito Pool Identity Id", idresult.getIdentityId());
            
            ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
            cognitoResponse.setServiceStatus(serviceStatus);
            cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
          }
        }
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception)
      {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("FederatedUserService", "servecognitoPoolUsertIdentity--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveDeleteIdentityFromPool(AWSBaseRequest awsBaseRequest) throws CognitoServiceException {
    LogUtil.serviceInfo("FederatedUserService", "serveDeleteIdentityFromPool--START");
    if ((awsBaseRequest instanceof CognitoGetRequest)) {
      CognitoGetRequest cognitoGetRequest = (CognitoGetRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        cognitoResponse = new CognitoResponse();
        AmazonCognitoIdentity getawsclient = amazonCognitoIdentityGenerator.getawsclient();
        DeleteIdentitiesRequest request = new DeleteIdentitiesRequest();
        
        DeleteIdentitiesResult deleteIdentities = getawsclient.deleteIdentities(request.withIdentityIdsToDelete(new String[] {cognitoGetRequest.getGetRequestValue() }));
        processResponse.setValues("Deleted Identity Id", cognitoGetRequest.getGetRequestValue());
        BigInteger statusCode = BigInteger.valueOf(deleteIdentities.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("FederatedUserService", "serveDeleteIdentityFromPool--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveGoogleUrl() throws CognitoServiceException
  {
    LogUtil.serviceInfo("FederatedUserService", "serveGoogleUrl--START");
    try {
      processResponse.createOrCleanMap();
      cognitoResponse = new CognitoResponse();
      String url = googleTokenGenerator.getGoogleLoginUrl(amazonCognitoIdentityGenerator);
      processResponse.setValues("Google URL", url);
      
      ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(0L));
      cognitoResponse.setServiceStatus(serviceStatus);
      cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
    }
    catch (NullPointerException nullPointerException) {
      throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
    }
    catch (Exception exc) {
      throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
    }
    LogUtil.serviceInfo("FederatedUserService", "serveGoogleUrl--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveFacebookUrl() throws CognitoServiceException
  {
    LogUtil.serviceInfo("FederatedUserService", "serveFacebookUrl--START");
    try {
      processResponse.createOrCleanMap();
      cognitoResponse = new CognitoResponse();
      String url = facebookTokenGenerater.getFacebookLoginUrl(amazonCognitoIdentityGenerator);
      processResponse.setValues("Facebook URL", url);
      
      ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(0L));
      cognitoResponse.setServiceStatus(serviceStatus);
      cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
    }
    catch (NullPointerException nullPointerException) {
      throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
    }
    catch (Exception exc) {
      throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
    }
    LogUtil.serviceInfo("FederatedUserService", "serveFacebookUrl--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveGoogleTokenID(AWSBaseRequest awsBaseRequest) throws CognitoServiceException
  {
    LogUtil.serviceInfo("FederatedUserService", "serveGoogleTokenID--START");
    if ((awsBaseRequest instanceof CognitoGetRequest)) {
      CognitoGetRequest cognitoGetRequest = (CognitoGetRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        cognitoResponse = new CognitoResponse();
        String tokenFromCode = googleTokenGenerator.getTokenFromCode(cognitoGetRequest.getGetRequestValue(), amazonCognitoIdentityGenerator);
        
        GetIdResult idresult = getGoogleFederatedIdentityByToken(tokenFromCode);
        processResponse.setValues("Google IdentityId", idresult.getIdentityId());
        
        BigInteger statusCode = BigInteger.valueOf(idresult.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (ConnectException connectException) {
        throw new CognitoServiceException(connectException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.CONNECT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("FederatedUserService", "serveGoogleTokenID--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveFacebookTokenID(AWSBaseRequest awsBaseRequest) throws CognitoServiceException
  {
    LogUtil.serviceInfo("FederatedUserService", "serveFacebookTokenID--START");
    if ((awsBaseRequest instanceof CognitoGetRequest)) {
      CognitoGetRequest cognitoGetRequest = (CognitoGetRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        cognitoResponse = new CognitoResponse();
        String tokenFromCode = facebookTokenGenerater.getTokenFromCode(cognitoGetRequest.getGetRequestValue(), amazonCognitoIdentityGenerator);
        

        GetIdResult idresult = getFacebookFederatedIdentityByToken(tokenFromCode);
        processResponse.setValues("Facebook Identity", idresult.getIdentityId());
        BigInteger statusCode = BigInteger.valueOf(idresult.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (ResourceAccessException resourceAccessException) {
        throw new CognitoServiceException(resourceAccessException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.CONNECT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("FederatedUserService", "serveFacebookTokenID--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveTestServices() throws CognitoServiceException
  {
    LogUtil.serviceInfo("FederatedUserService", "serveTestServices--START");
    try {
      cognitoResponse = new CognitoResponse();
      processResponse.createOrCleanMap();
      processResponse.setValues("Service Details", "Service is Up and running");
      ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(0L));
      cognitoResponse.setServiceStatus(serviceStatus);
      cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
    }
    catch (NullPointerException nullPointerException)
    {
      throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
    }
    catch (Exception exc) {
      throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
    }
    LogUtil.serviceInfo("FederatedUserService", "serveTestServices--END");
    return cognitoResponse;
  }
  
  private GetIdResult getGoogleFederatedIdentityByToken(String tokenId) throws CognitoServiceException {
    LogUtil.serviceInfo("FederatedUserService", "getGoogleFederatedIdentityByToken--START");
    AmazonCognitoIdentity getawsclient = amazonCognitoIdentityGenerator.getawsclient();
    GetIdRequest getIdRequest = new GetIdRequest();
    getIdRequest.setIdentityPoolId(amazonCognitoIdentityGenerator.get_amazonCognitoGoogleFederatedPoolId());
    Map<String, String> logins = new HashMap();
    logins.put(amazonCognitoIdentityGenerator.get_amazonGoogleLoginKey(), tokenId);
    getIdRequest.setLogins(logins);
    GetIdResult idresult = getawsclient.getId(getIdRequest);
    LogUtil.serviceInfo("FederatedUserService", "getGoogleFederatedIdentityByToken--END");
    return idresult;
  }
  
  private GetIdResult getFacebookFederatedIdentityByToken(String tokenId) throws CognitoServiceException
  {
    LogUtil.serviceInfo("FederatedUserService", "getFacebookFederatedIdentityByToken--START");
    AmazonCognitoIdentity getawsclient = amazonCognitoIdentityGenerator.getawsclient();
    GetIdRequest getIdRequest = new GetIdRequest();
    getIdRequest.setIdentityPoolId(amazonCognitoIdentityGenerator.get_amazonCognitoFacebookFederatedPoolId());
    Map<String, String> logins = new HashMap();
    logins.put(amazonCognitoIdentityGenerator.get_amazonFacebookLoginKey(), tokenId);
    getIdRequest.setLogins(logins);
    GetIdResult idresult = getawsclient.getId(getIdRequest);
    LogUtil.serviceInfo("FederatedUserService", "getFacebookFederatedIdentityByToken--END");
    return idresult;
  }
}
