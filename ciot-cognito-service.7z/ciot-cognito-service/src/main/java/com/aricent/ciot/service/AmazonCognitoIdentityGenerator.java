package com.aricent.ciot.service;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentity;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentityClientBuilder;
import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.iot.common.utils.LogUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
































@Service
public class AmazonCognitoIdentityGenerator
{
  @Value("${spring.application.name}")
  public String springApplicationName;
  @Value("${aws.accesskey}")
  private String awsaccesskey;
  @Value("${aws.secretkey}")
  private String awssecretkey;
  @Value("${AWSCognito.config.region}")
  private String awsregion;
  @Value("${AWSCognito.clientid}")
  private String _cognitoClientId;
  @Value("${AWSCognito.userpoolid}")
  private String _cognitoUserpoolId;
  @Value("${AMAZONCognito.cognito.federated.poolid}")
  private String _amazonCognitoFederatedPoolId;
  @Value("${AMAZONCognito.google.fedreated.poolid}")
  private String _amazonCognitoGoogleFederatedPoolId;
  @Value("${AMAZONCognito.google.login.key}")
  private String _amazonGoogleLoginKey;
  @Value("${google.client.id}")
  private String _googleClientId;
  @Value("${google.client.seceret.id}")
  private String _googleSecretId;
  @Value("${google.client.scope}")
  private String _googleScope;
  @Value("${google.login.redirect.uri}")
  private String _googleLoginRedirectUri;
  @Value("${AMAZONCognito.facebook.fedreated.poolid}")
  private String _amazonCognitoFacebookFederatedPoolId;
  @Value("${AMAZONCognito.facebook.login.key}")
  private String _amazonFacebookLoginKey;
  @Value("${facebook.client.id}")
  private String _facebookClientId;
  @Value("${facebook.client.seceret.id}")
  private String _facebookSecretId;
  @Value("${facebook.client.scope}")
  private String _facebookScope;
  @Value("${facebook.login.redirect.uri}")
  private String _facebookLoginRedirectUri;
  @Autowired
  private BuildConfiguration buildConfiguration;
  
  public AmazonCognitoIdentityGenerator() {}
  
  public AmazonCognitoIdentity getawsclient()
    throws CognitoServiceException
  {
    LogUtil.info("AmazonCognitoIdentity", "getawsclient--START");
    ClientConfiguration configuration = buildConfiguration.getClientConfiguration();
    BasicAWSCredentials awsCreds = new BasicAWSCredentials(awsaccesskey, awssecretkey);
    

    AmazonCognitoIdentity client = (AmazonCognitoIdentity)((AmazonCognitoIdentityClientBuilder)((AmazonCognitoIdentityClientBuilder)((AmazonCognitoIdentityClientBuilder)AmazonCognitoIdentityClientBuilder.standard().withClientConfiguration(configuration)).withRegion(awsregion)).withCredentials(new AWSStaticCredentialsProvider(awsCreds))).build();
    LogUtil.info("AmazonCognitoIdentity", "getawsclient--END");
    
    return client;
  }
  
  public String get_cognitoClientId() {
    return _cognitoClientId;
  }
  
  public String get_cognitoUserpoolId() {
    return _cognitoUserpoolId;
  }
  
  public String get_amazonCognitoFederatedPoolId() {
    return _amazonCognitoFederatedPoolId;
  }
  
  public String get_amazonCognitoGoogleFederatedPoolId() {
    return _amazonCognitoGoogleFederatedPoolId;
  }
  
  public String get_amazonGoogleLoginKey() {
    return _amazonGoogleLoginKey;
  }
  
  public String get_googleClientId() {
    return _googleClientId;
  }
  
  public String get_googleSecretId() {
    return _googleSecretId;
  }
  
  public String getAwsregion() {
    return awsregion;
  }
  
  public String get_googleScope() {
    return _googleScope;
  }
  
  public String get_amazonCognitoFacebookFederatedPoolId() {
    return _amazonCognitoFacebookFederatedPoolId;
  }
  
  public String get_amazonFacebookLoginKey() {
    return _amazonFacebookLoginKey;
  }
  
  public String get_facebookClientId() {
    return _facebookClientId;
  }
  
  public String get_facebookSecretId() {
    return _facebookSecretId;
  }
  
  public String get_facebookScope() {
    return _facebookScope;
  }
  
  public String get_googleLoginRedirectUri() {
    return _googleLoginRedirectUri;
  }
  
  public String get_facebookLoginRedirectUri() {
    return _facebookLoginRedirectUri;
  }
  
  public String getSpringApplicationName() {
    return springApplicationName;
  }
}
