package com.aricent.ciot.model;

import com.aricent.iot.common.model.AWSBaseRequest;


public class CognitoGetRequest
  extends AWSBaseRequest
{
  private static final long serialVersionUID = 1L;
  private String getRequestParameter;
  private String getRequestValue;
  
  public CognitoGetRequest(String invokedBy, String webServiceId, String date, String getRequestValue, String getRequestParameter)
  {
    super(invokedBy, webServiceId, date);
    this.getRequestValue = getRequestValue;
    this.getRequestParameter = getRequestParameter;
  }
  

  public CognitoGetRequest() {}
  
  public String getGetRequestValue()
  {
    return getRequestValue;
  }
  
  public void setGetRequestValue(String getRequestValue) {
    this.getRequestValue = getRequestValue;
  }
  
  public String getGetRequestParameter() {
    return getRequestParameter;
  }
  
  public void setGetRequestParameter(String getRequestParameter) {
    this.getRequestParameter = getRequestParameter;
  }
}
