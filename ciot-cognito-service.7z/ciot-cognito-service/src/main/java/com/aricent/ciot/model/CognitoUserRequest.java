package com.aricent.ciot.model;

import com.aricent.iot.common.model.AWSBaseRequest;
import java.util.Map;
import org.springframework.stereotype.Component;








@Component
public class CognitoUserRequest
  extends AWSBaseRequest
{
  private String userName;
  private Map<String, String> atrributes;
  private String password;
  private String finalPassword;
  private String code;
  private String token;
  
  public CognitoUserRequest() {}
  
  public CognitoUserRequest(String invokedBy, String webServiceId, String date)
  {
    super(invokedBy, webServiceId, date);
  }
  
  public String getUserName() {
    return userName;
  }
  
  public void setUserName(String userName) { this.userName = userName; }
  
  public Map<String, String> getAtrributes() {
    return atrributes;
  }
  
  public void setAtrributes(Map<String, String> atrributes) { this.atrributes = atrributes; }
  
  public String getPassword() {
    return password;
  }
  
  public void setPassword(String password) { this.password = password; }
  
  public String getFinalPassword() {
    return finalPassword;
  }
  
  public void setFinalPassword(String finalPassword) { this.finalPassword = finalPassword; }
  
  public String getCode() {
    return code;
  }
  
  public void setCode(String code) { this.code = code; }
  
  public String getToken()
  {
    return token;
  }
  
  public void setToken(String token) {
    this.token = token;
  }
}
