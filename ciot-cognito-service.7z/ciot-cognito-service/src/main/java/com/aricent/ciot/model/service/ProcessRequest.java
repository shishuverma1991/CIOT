package com.aricent.ciot.model.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.cognitoidp.model.AdminCreateUserRequest;
import com.amazonaws.services.cognitoidp.model.AttributeType;
import com.aricent.ciot.model.CognitoUserRequest;

public class ProcessRequest
{

	public AdminCreateUserRequest processUserDetails(CognitoUserRequest cognitoUserRequest) {
		
		AdminCreateUserRequest adminCreateUserRequest=new AdminCreateUserRequest();
		adminCreateUserRequest.setUsername(cognitoUserRequest.getUserName());
		adminCreateUserRequest.setTemporaryPassword(cognitoUserRequest.getPassword());
		
		Map<String, String> atrributes = cognitoUserRequest.getAtrributes();
		adminCreateUserRequest.setUserAttributes(createAttributeList(atrributes));
		
		
		return null;
	}

	private Collection<AttributeType> createAttributeList(Map<String, String> atrributes) {
		
		List<AttributeType> attributeList=new ArrayList<AttributeType>();
		
		for (String attributeType : atrributes.keySet()) {
			AttributeType type=new AttributeType();
			type.setName(attributeType);
			type.setValue(atrributes.get(attributeType));
			attributeList.add(type);
		}
		return attributeList;
	}
	




}