package com.aricent.ciot.controller;

import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.ciot.model.CognitoResponse;
import com.aricent.ciot.model.CognitoUserRequest;
import com.aricent.ciot.model.service.CognitoGetRequestValidator;
import com.aricent.ciot.model.service.CognitoResponsehandler;
import com.aricent.ciot.model.service.CognitoUserRequestValidator;
import com.aricent.ciot.service.CognitoPoolUserService;
import com.aricent.iot.common.model.AWSBaseRequest;
import com.aricent.iot.common.model.ErrorDetail;
import com.aricent.iot.common.utils.LogUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({ "/cognito/pooluser" })
@Api("Cognito Pool user Controller")
@CrossOrigin(origins = { "*" })
public class AWSCognitoController {
    @Autowired
    private CognitoGetRequestValidator  cognitoGetRequestValidator;
    @Autowired
    private CognitoUserRequestValidator cognitoUserRequestValidator;
    @Autowired
    private CognitoPoolUserService      cognitoPoolUserService;
    @Autowired
    private CognitoResponsehandler      cognitoResponsehandler;
    private CognitoResponse             cognitoResponse;
    
    public AWSCognitoController() {
    }
    
    @GetMapping(value = { "/retrieveuser/{username}" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "View a list of attributes for the specified user", response = CognitoResponse.class)
    public CognitoResponse retrieveUser(@PathVariable("username") String username) {
        LogUtil.endPointInfo("AWSCognitoController", "retrieveUser--START");
        try {
            AWSBaseRequest cognitoGetRequest = cognitoPoolUserService.prepareCognitoPoolUserGetRequest("username",
                            username);
            
            List<ErrorDetail> errorDetails = cognitoGetRequestValidator.validate(cognitoGetRequest);
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoGetRequestValidator.getValidationResponse(cognitoGetRequest,
                                errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveAdminGetUserResult(cognitoGetRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "retrieveUser", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "retrieveUser--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @GetMapping(value = { "/resetpassword/{username}" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "reset user password", response = CognitoResponse.class)
    public CognitoResponse resetUserPassward(@PathVariable("username") String username) {
        LogUtil.endPointInfo("AWSCognitoController", "resetUserPassward--START");
        try {
            AWSBaseRequest cognitoGetRequest = cognitoPoolUserService.prepareCognitoPoolUserGetRequest("username",
                            username);
            
            List<ErrorDetail> errorDetails = cognitoGetRequestValidator.validate(cognitoGetRequest);
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoGetRequestValidator.getValidationResponse(cognitoGetRequest,
                                errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveResetUserPassward(cognitoGetRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "resetUserPassward", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "resetUserPassward--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @GetMapping(value = { "/test" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "Test rest service state", response = CognitoResponse.class)
    public CognitoResponse testServices() {
        LogUtil.endPointInfo("AWSCognitoController", "testServices--START");
        try {
            cognitoResponse = cognitoPoolUserService.serveTestServices();
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "testServices", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "testServices--END");
        return cognitoResponse;
    }
    
    @DeleteMapping(value = { "/deleteuser/{username}" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "Delete a user with username", response = CognitoResponse.class)
    public CognitoResponse deleteUser(@PathVariable String username) {
        LogUtil.endPointInfo("AWSCognitoController", "deleteUser--START");
        try {
            AWSBaseRequest cognitoGetRequest = cognitoPoolUserService.prepareCognitoPoolUserGetRequest("username",
                            username);
            
            List<ErrorDetail> errorDetails = cognitoGetRequestValidator.validate(cognitoGetRequest);
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoGetRequestValidator.getValidationResponse(cognitoGetRequest,
                                errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveDeleteUser(cognitoGetRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "deleteUser", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "deleteUser--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @PostMapping(value = { "/regesteruser/" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "ADD a user with attributes", response = CognitoResponse.class)
    public CognitoResponse resgesterUser(@RequestBody CognitoUserRequest userDetails) {
        LogUtil.endPointInfo("AWSCognitoController", "resgesterUser--START");
        try {
            AWSBaseRequest cognitoUserRequest = cognitoPoolUserService.prepareCognitoUserRequest(userDetails);
            List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validate(cognitoUserRequest,
                            new String[] { "username", "attribute" });
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoUserRequestValidator
                                .getValidationResponse(cognitoUserRequest, errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveResgesterUser(cognitoUserRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "resgesterUser", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "resgesterUser--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @PostMapping(value = { "/changedefaultpassword/" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "Change Default User Password", response = CognitoResponse.class)
    public CognitoResponse changeDefaultUserPassword(@RequestBody CognitoUserRequest userDetails) {
        LogUtil.endPointInfo("AWSCognitoController", "changeDefaultUserPassword--START");
        try {
            AWSBaseRequest cognitoUserRequest = cognitoPoolUserService.prepareCognitoUserRequest(userDetails);
            List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validate(cognitoUserRequest,
                            new String[] { "username", "password", "finalpassword" });
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoUserRequestValidator
                                .getValidationResponse(cognitoUserRequest, errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveChangeDefaultUserPassword(cognitoUserRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "changeDefaultUserPassword", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "changeDefaultUserPassword--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @PostMapping(value = { "/forgotpassword/" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "get code for Forgot Password", response = CognitoResponse.class)
    public CognitoResponse codeGenerationOnForgotPassword(@RequestBody CognitoUserRequest userDetails) {
        LogUtil.endPointInfo("AWSCognitoController", "codeGenerationOnForgotPassword--START");
        try {
            AWSBaseRequest cognitoUserRequest = cognitoPoolUserService.prepareCognitoUserRequest(userDetails);
            List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validate(cognitoUserRequest,
                            new String[] { "username" });
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoUserRequestValidator
                                .getValidationResponse(cognitoUserRequest, errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveCodeGenerationOnForgotPassword(cognitoUserRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "codeGenerationOnForgotPassword", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "codeGenerationOnForgotPassword--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @PostMapping(value = { "/confirmforgotpassword/" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "set new password with code", response = CognitoResponse.class)
    public CognitoResponse confirmForgotPassword(@RequestBody CognitoUserRequest userDetails) {
        LogUtil.endPointInfo("AWSCognitoController", "confirmForgotPassword--START");
        try {
            AWSBaseRequest cognitoUserRequest = cognitoPoolUserService.prepareCognitoUserRequest(userDetails);
            List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validate(cognitoUserRequest,
                            new String[] { "username", "code", "finalpassword" });
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoUserRequestValidator
                                .getValidationResponse(cognitoUserRequest, errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveConfirmForgotPassword(cognitoUserRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "confirmForgotPassword", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "confirmForgotPassword--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @PostMapping(value = { "/loginPoolUser/" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "Login Pool User", response = CognitoResponse.class)
    public CognitoResponse loginPoolUser(@RequestBody CognitoUserRequest userDetails) {
        LogUtil.endPointInfo("AWSCognitoController", "loginPoolUser--START");
        try {
            AWSBaseRequest cognitoUserRequest = cognitoPoolUserService.prepareCognitoUserRequest(userDetails);
            List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validate(cognitoUserRequest,
                            new String[] { "username", "password" });
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoUserRequestValidator
                                .getValidationResponse(cognitoUserRequest, errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveLoginPoolUser(cognitoUserRequest,
                                cognitoUserRequestValidator);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "loginPoolUser", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "loginPoolUser--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @PostMapping(value = { "/logoutPoolUser/" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "Logout Pool User", response = CognitoResponse.class)
    public CognitoResponse logoutPoolUser(@RequestBody CognitoUserRequest userDetails) {
        LogUtil.endPointInfo("AWSCognitoController", "logoutPoolUser--START");
        try {
            AWSBaseRequest cognitoUserRequest = cognitoPoolUserService.prepareCognitoUserRequest(userDetails);
            List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validate(cognitoUserRequest,
                            new String[] { "username", "token" });
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoUserRequestValidator
                                .getValidationResponse(cognitoUserRequest, errorDetails));
            } else {
                cognitoResponse = cognitoPoolUserService.serveLogoutPoolUser(cognitoUserRequest,
                                cognitoUserRequestValidator);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AWSCognitoController", "logoutPoolUser", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AWSCognitoController", "logoutPoolUser--END", cognitoResponse.toString());
        return cognitoResponse;
    }
}
