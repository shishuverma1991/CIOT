package com.aricent.ciot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.ciot.model.CognitoResponse;
import com.aricent.ciot.model.CognitoUserRequest;
import com.aricent.ciot.model.service.CognitoGetRequestValidator;
import com.aricent.ciot.model.service.CognitoResponsehandler;
import com.aricent.ciot.model.service.CognitoUserRequestValidator;
import com.aricent.ciot.service.FederatedUserService;
import com.aricent.iot.common.model.AWSBaseRequest;
import com.aricent.iot.common.model.ErrorDetail;
import com.aricent.iot.common.utils.LogUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping({ "/cognito/federateduser" })
@Api("Cognito Federated Controller")
@CrossOrigin(origins = { "*" })
public class AmazonCognitoController {
    @Autowired
    private CognitoGetRequestValidator  cognitoGetRequestValidator;
    @Autowired
    private CognitoUserRequestValidator cognitoUserRequestValidator;
    @Autowired
    private FederatedUserService        federatedUserService;
    @Autowired
    private CognitoResponsehandler      cognitoResponsehandler;
    @Autowired
    private CognitoResponse             cognitoResponse;
    
    public AmazonCognitoController() {
    }
    
    @PostMapping(value = { "/cogintouser/identity" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation("view Id for the federated user")
    public CognitoResponse cognitoPoolUsertIdentity(@RequestBody CognitoUserRequest userDetails) {
        LogUtil.endPointInfo("AmazonCognitoController", "cognitoPoolUsertIdentity--START");
        try {
            AWSBaseRequest cognitoUserRequest = federatedUserService.prepareCognitoUserRequest(userDetails);
            List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validate(cognitoUserRequest,
                            new String[] { "username", "password" });
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoUserRequestValidator
                                .getValidationResponse(cognitoUserRequest, errorDetails));
            } else {
                cognitoResponse = federatedUserService.servecognitoPoolUsertIdentity(cognitoUserRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            
            LogUtil.errorInfo("AmazonCognitoController", "cognitoPoolUsertIdentity", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AmazonCognitoController", "cognitoPoolUsertIdentity--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @GetMapping({ "/googleuser/loginurl" })
    @ApiOperation("get URL for google code")
    public CognitoResponse getURLViaGoogle() {
        LogUtil.endPointInfo("AmazonCognitoController", "getURLViaGoogle--START");
        try {
            cognitoResponse = federatedUserService.serveGoogleUrl();
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AmazonCognitoController", "getURLViaGoogle", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AmazonCognitoController", "getURLViaGoogle--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @GetMapping({ "/googleuser/exchangecode" })
    @ApiOperation("get Token for google user")
    public CognitoResponse getGoogleTokenByCode(@RequestParam("code") String code) {
        LogUtil.endPointInfo("AmazonCognitoController", "getGoogleTokenByCode--START");
        try {
            AWSBaseRequest cognitoGetRequest = federatedUserService.prepareCognitoPoolUserGetRequest("code", code);
            
            List<ErrorDetail> errorDetails = cognitoGetRequestValidator.validate(cognitoGetRequest);
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoGetRequestValidator.getValidationResponse(cognitoGetRequest,
                                errorDetails));
            } else {
                cognitoResponse = federatedUserService.serveGoogleTokenID(cognitoGetRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AmazonCognitoController", "getGoogleTokenByCode", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AmazonCognitoController", "getGoogleTokenByCode--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @GetMapping({ "/facebookuser/loginurl" })
    @ApiOperation("get URL for facebook code")
    public CognitoResponse getURLViaFacebook() {
        LogUtil.endPointInfo("AmazonCognitoController", "getURLViaFacebook--START");
        try {
            cognitoResponse = federatedUserService.serveFacebookUrl();
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AmazonCognitoController", "getURLViaFacebook", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AmazonCognitoController", "getURLViaFacebook--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @GetMapping({ "/facebookuser/exchangecode" })
    @ApiOperation("get Token for facebook user ")
    public CognitoResponse getFacebookTokenByCode(@RequestParam("code") String code) {
        LogUtil.endPointInfo("AmazonCognitoController", "getFacebookTokenByCode--START");
        try {
            AWSBaseRequest cognitoGetRequest = federatedUserService.prepareCognitoPoolUserGetRequest("code", code);
            
            List<ErrorDetail> errorDetails = cognitoGetRequestValidator.validate(cognitoGetRequest);
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoGetRequestValidator.getValidationResponse(cognitoGetRequest,
                                errorDetails));
            } else {
                cognitoResponse = federatedUserService.serveFacebookTokenID(cognitoGetRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AmazonCognitoController", "getFacebookTokenByCode", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AmazonCognitoController", "getFacebookTokenByCode--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @DeleteMapping({ "/delete/identity/{id}" })
    public CognitoResponse deleteIdentityFromPool(@PathVariable(name = "id") String id) {
        LogUtil.endPointInfo("AmazonCognitoController", "deleteIdentityFromPool--START");
        try {
            AWSBaseRequest cognitoGetRequest = federatedUserService.prepareCognitoPoolUserGetRequest("federated id",
                            id);
            
            List<ErrorDetail> errorDetails = cognitoGetRequestValidator.validate(cognitoGetRequest);
            if (errorDetails.size() > 0) {
                cognitoResponse = ((CognitoResponse) cognitoGetRequestValidator.getValidationResponse(cognitoGetRequest,
                                errorDetails));
            } else {
                cognitoResponse = federatedUserService.serveDeleteIdentityFromPool(cognitoGetRequest);
            }
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AmazonCognitoController", "deleteIdentityFromPool", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AmazonCognitoController", "deleteIdentityFromPool--END", cognitoResponse.toString());
        return cognitoResponse;
    }
    
    @GetMapping(value = { "/test" }, produces = { "application/json" })
    @ResponseBody
    @ApiOperation(value = "Test rest service state", response = CognitoResponse.class)
    public CognitoResponse testServices() {
        LogUtil.endPointInfo("AmazonCognitoController", "testServices--START");
        try {
            cognitoResponse = federatedUserService.serveTestServices();
        } catch (CognitoServiceException exception) {
            if (null == cognitoResponse) {
                cognitoResponse = new CognitoResponse();
            }
            LogUtil.errorInfo("AmazonCognitoController", "testServices", exception);
            cognitoResponsehandler.handleResponse(cognitoResponse, exception);
        }
        LogUtil.endPointInfo("AmazonCognitoController", "testServices--END", cognitoResponse.toString());
        return cognitoResponse;
    }
}
