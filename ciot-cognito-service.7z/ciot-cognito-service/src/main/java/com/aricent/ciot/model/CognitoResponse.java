package com.aricent.ciot.model;

import com.aricent.iot.common.model.AWSBaseResponse;
import com.aricent.iot.common.model.ErrorDetail;
import java.util.List;
import org.springframework.stereotype.Component;









@Component
public class CognitoResponse
  extends AWSBaseResponse
{
  private static final long serialVersionUID = 1L;
  private Object awsResponseObject;
  private List<ErrorDetail> errorDetails;
  
  public CognitoResponse() {}
  
  public Object getAwsResponseObject()
  {
    return awsResponseObject;
  }
  
  public void setAwsResponseObject(Object awsResponseObject) {
    this.awsResponseObject = awsResponseObject;
  }
  
  public List<ErrorDetail> getErrorDetails() {
    return errorDetails;
  }
  
  public void setErrorDetails(List<ErrorDetail> errorDetails) {
    this.errorDetails = errorDetails;
  }
}
