package com.aricent.ciot.service;

import com.aricent.iot.common.utils.LogUtil;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow.Builder;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeRequestUrl;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets.Details;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import org.springframework.stereotype.Service;








@Service
public class GoogleTokenGenerator
{
  private String OAUTH2_CLIENT_ID;
  private String OAUTH2_CLIENT_SECRET;
  private String[] OAUTH2_SCOPE;
  
  public GoogleTokenGenerator() {}
  
  public String getGoogleLoginUrl(AmazonCognitoIdentityGenerator amazonCognitoIdentityGenerator)
    throws IOException
  {
    LogUtil.info("GoogleTokenGenerator", "getGoogleLoginUrl--START");
    OAUTH2_CLIENT_ID = amazonCognitoIdentityGenerator.get_googleClientId();
    OAUTH2_CLIENT_SECRET = amazonCognitoIdentityGenerator.get_googleSecretId();
    OAUTH2_SCOPE = amazonCognitoIdentityGenerator.get_googleScope().split(",");
    GoogleAuthorizationCodeFlow flow = getAuthorizationCodeFlow(true);
    

    GoogleAuthorizationCodeRequestUrl setResponseTypes = flow.newAuthorizationUrl().setResponseTypes(Arrays.asList(new String[] { "code" })).setRedirectUri(amazonCognitoIdentityGenerator.get_googleLoginRedirectUri());
    LogUtil.info("GoogleTokenGenerator", "getGoogleLoginUrl--END");
    return setResponseTypes.build();
  }
  




  private GoogleClientSecrets createClientSecrets(String clientIdOverride, String clientSecretOverride)
  {
    return new GoogleClientSecrets().setInstalled(new GoogleClientSecrets.Details()
      .setClientId(clientIdOverride).setClientSecret(clientSecretOverride));
  }
  


  private GoogleClientSecrets getClientSecrets()
  {
    GoogleClientSecrets clientSecrets = createClientSecrets(OAUTH2_CLIENT_ID, OAUTH2_CLIENT_SECRET);
    return clientSecrets;
  }
  



  private GoogleAuthorizationCodeFlow getAuthorizationCodeFlow(boolean usePersistedCredentials)
    throws IOException
  {
    HttpTransport httpTransport = new NetHttpTransport();
    JsonFactory jsonFactory = new JacksonFactory();
    Collection<String> scopes = Arrays.asList(OAUTH2_SCOPE);
    GoogleClientSecrets clientSecrets = getClientSecrets();
    GoogleAuthorizationCodeFlow flow;
    if (usePersistedCredentials)
    {
      flow = new GoogleAuthorizationCodeFlow.Builder(httpTransport, jsonFactory, clientSecrets, scopes).setAccessType("offline").setApprovalPrompt("force").build();
    }
    else {
      flow = new GoogleAuthorizationCodeFlow.Builder(httpTransport, jsonFactory, clientSecrets, scopes).setAccessType("online").setApprovalPrompt("auto").build();
    }
    return flow;
  }
  





  public String getTokenFromCode(String code, AmazonCognitoIdentityGenerator amazonCognitoIdentityGenerator)
    throws IOException
  {
    LogUtil.info("GoogleTokenGenerator", "getTokenFromCode--START");
    GoogleAuthorizationCodeFlow flow = getAuthorizationCodeFlow(false);
    
    GoogleAuthorizationCodeTokenRequest newTokenRequest = flow.newTokenRequest(code).setRedirectUri(amazonCognitoIdentityGenerator.get_googleLoginRedirectUri());
    GoogleTokenResponse reponse = newTokenRequest.execute();
    LogUtil.info("GoogleTokenGenerator", "getTokenFromCode--END");
    
    return reponse.getIdToken();
  }
}
