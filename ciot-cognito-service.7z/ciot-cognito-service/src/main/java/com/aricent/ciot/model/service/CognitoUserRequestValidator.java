package com.aricent.ciot.model.service;

import com.aricent.ciot.helper.StringUtils;
import com.aricent.ciot.model.CognitoResponse;
import com.aricent.ciot.model.CognitoUserRequest;
import com.aricent.iot.common.model.AWSBaseRequest;
import com.aricent.iot.common.model.AWSBaseResponse;
import com.aricent.iot.common.model.ErrorDetail;
import com.aricent.iot.common.model.ServiceStatus;
import com.aricent.iot.common.validator.AWSValidator;
import com.aricent.statuscodes.AWSErrorCodes;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




@Service
public class CognitoUserRequestValidator
  implements AWSValidator
{
  @Autowired
  private ProcessResponse processResponse;
  
  public CognitoUserRequestValidator() {}
  
  public List<ErrorDetail> validate(AWSBaseRequest baseRequest)
  {
    return null;
  }
  

  public AWSBaseResponse getValidationResponse(AWSBaseRequest baseRequest, List<ErrorDetail> errorList)
  {
    processResponse.createOrCleanMap();
    ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(1L));
    if ((baseRequest instanceof CognitoUserRequest)) {
      CognitoResponse cognitoResponse = new CognitoResponse();
      processResponse.setValues("Service Details", " Service Failure!");
      
      cognitoResponse.setServiceStatus(serviceStatus);
      cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      cognitoResponse.setErrorDetails(errorList);
      return cognitoResponse;
    }
    
    return null;
  }
  



  public List<ErrorDetail> validateUserName(AWSBaseRequest baseRequest, String targetString)
  {
    List<ErrorDetail> errorDetails = new ArrayList();
    if ((baseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest request = (CognitoUserRequest)baseRequest;
      if (!StringUtils.checkStringsAreEqual(request.getUserName(), targetString)) {
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
        errorDetail.setErrorDescription("Parameter invalid/missing. Please provide User name.");
        errorDetails.add(errorDetail);
      }
    }
    return errorDetails;
  }
  



  public List<ErrorDetail> validate(AWSBaseRequest baseRequest, String... parametrs)
  {
    List<ErrorDetail> errorDetails = new ArrayList();
    
    if ((baseRequest instanceof CognitoUserRequest))
    {
      CognitoUserRequest request = (CognitoUserRequest)baseRequest;
      ErrorDetail errorDetail = null;
      

      for (String param : parametrs) {
        switch (param) {
        case "username": 
          if (StringUtils.isBlank(request.getUserName())) {
            errorDetail = new ErrorDetail();
            errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
            errorDetail.setErrorDescription("Parameter invalid/missing. Please provide User name.");
            errorDetails.add(errorDetail);
          }
          break;
        case "code": 
          if (StringUtils.isBlank(request.getCode())) {
            errorDetail = new ErrorDetail();
            errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
            errorDetail.setErrorDescription("Parameter invalid/missing. Please provide code.");
            errorDetails.add(errorDetail);
          }
          break;
        case "password": 
          if (StringUtils.isBlank(request.getPassword())) {
            errorDetail = new ErrorDetail();
            errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
            errorDetail.setErrorDescription("Parameter invalid/missing. Please provide password.");
            errorDetails.add(errorDetail);
          }
          break;
        case "finalpassword": 
          if (StringUtils.isBlank(request.getFinalPassword())) {
            errorDetail = new ErrorDetail();
            errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
            errorDetail.setErrorDescription("Parameter invalid/missing. Please provide final Password.");
            errorDetails.add(errorDetail);
          }
          break;
        case "attribute": 
          if (StringUtils.checkListisNotEmpty(request.getAtrributes().entrySet())) {
            errorDetail = new ErrorDetail();
            errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
            errorDetail.setErrorDescription("Parameter invalid/missing. Please provide attributes.");
            errorDetails.add(errorDetail);
          }
          
          break;
        case "token": 
          if (StringUtils.isBlank(request.getToken())) {
            errorDetail = new ErrorDetail();
            errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
            errorDetail.setErrorDescription("Parameter invalid/missing. Please provide Token.");
            errorDetails.add(errorDetail);
          }
          

          break;
        }
        
      }
    }
    
    return errorDetails;
  }
}
