package com.aricent.ciot.service;

import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AdminRespondToAuthChallengeRequest;
import com.amazonaws.services.cognitoidp.model.AdminRespondToAuthChallengeResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.amazonaws.services.cognitoidp.model.AuthenticationResultType;
import com.amazonaws.services.cognitoidp.model.ChallengeNameType;
import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.ciot.model.CognitoUserRequest;
import com.aricent.iot.common.utils.LogUtil;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;









@Service
public class TokenGenerator
{
  @Autowired
  private AWSCognitoIdentityGenerator amazonCognitoIdentityGenerator;
  
  public TokenGenerator() {}
  
  public String generateToken(CognitoUserRequest userDetails)
    throws CognitoServiceException
  {
    LogUtil.info("AWSCognitoIdentityGenerator", "generateToken--START");
    String response = null;
    AWSCognitoIdentityProvider client = amazonCognitoIdentityGenerator.getawsclient();
    Map<String, String> authParams = new HashMap();
    authParams.put("USERNAME", userDetails.getUserName());
    authParams.put("PASSWORD", userDetails.getPassword());
    



    AdminInitiateAuthRequest authRequest = new AdminInitiateAuthRequest().withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH).withAuthParameters(authParams).withClientId(amazonCognitoIdentityGenerator.get_cognitoClientId()).withUserPoolId(amazonCognitoIdentityGenerator.get_cognitoUserpoolId());
    
    AdminInitiateAuthResult authResponse = client.adminInitiateAuth(authRequest);
    
    if (ChallengeNameType.NEW_PASSWORD_REQUIRED.name().equals(authResponse.getChallengeName())) {
      response = ChallengeNameType.NEW_PASSWORD_REQUIRED.name();
    } else {
      response = authResponse.getAuthenticationResult().getIdToken();
    }
    LogUtil.info("AWSCognitoIdentityGenerator", "generateToken--END");
    return response;
  }
  











  public AdminRespondToAuthChallengeResult completeNewPasswordChallenge(CognitoUserRequest userDetails, AdminInitiateAuthResult adminInitiateAuthResult, AWSCognitoIdentityProvider client)
    throws CognitoServiceException
  {
    LogUtil.info("AWSCognitoIdentityGenerator", "completeNewPasswordChallenge--START");
    Map<String, String> challengeResponses = new HashMap();
    challengeResponses.put("USERNAME", userDetails.getUserName());
    challengeResponses.put("PASSWORD", userDetails.getPassword());
    challengeResponses.put("NEW_PASSWORD", userDetails.getFinalPassword());
    




    AdminRespondToAuthChallengeRequest finalRequest = new AdminRespondToAuthChallengeRequest().withChallengeName(ChallengeNameType.NEW_PASSWORD_REQUIRED).withChallengeResponses(challengeResponses).withClientId(amazonCognitoIdentityGenerator.get_cognitoClientId()).withUserPoolId(amazonCognitoIdentityGenerator.get_cognitoUserpoolId()).withSession(adminInitiateAuthResult.getSession());
    
    AdminRespondToAuthChallengeResult challengeResponse = client.adminRespondToAuthChallenge(finalRequest);
    LogUtil.info("AWSCognitoIdentityGenerator", "completeNewPasswordChallenge--END");
    return challengeResponse;
  }
  







  public AdminInitiateAuthResult getAccessToken(CognitoUserRequest userDetails, AWSCognitoIdentityProvider client)
  {
    LogUtil.info("AWSCognitoIdentityGenerator", "getAccessToken--START");
    AdminInitiateAuthResult authResponse = null;
    
    Map<String, String> authParams = new HashMap();
    
    authParams.put("USERNAME", userDetails.getUserName());
    authParams.put("PASSWORD", userDetails.getPassword());
    



    AdminInitiateAuthRequest authRequest = new AdminInitiateAuthRequest().withAuthFlow(AuthFlowType.ADMIN_NO_SRP_AUTH).withAuthParameters(authParams).withClientId(amazonCognitoIdentityGenerator.get_cognitoClientId()).withUserPoolId(amazonCognitoIdentityGenerator.get_cognitoUserpoolId());
    
    authResponse = client.adminInitiateAuth(authRequest);
    LogUtil.info("AWSCognitoIdentityGenerator", "getAccessToken--END");
    return authResponse;
  }
}
