package com.aricent.ciot.model.service;

import com.aricent.ciot.helper.StringUtils;
import com.aricent.ciot.model.CognitoGetRequest;
import com.aricent.ciot.model.CognitoResponse;
import com.aricent.iot.common.model.AWSBaseRequest;
import com.aricent.iot.common.model.AWSBaseResponse;
import com.aricent.iot.common.model.ErrorDetail;
import com.aricent.iot.common.model.ServiceStatus;
import com.aricent.iot.common.validator.AWSValidator;
import com.aricent.statuscodes.AWSErrorCodes;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CognitoGetRequestValidator implements AWSValidator
{
  @Autowired
  private ProcessResponse processResponse;
  
  public CognitoGetRequestValidator() {}
  
  public List<ErrorDetail> validate(AWSBaseRequest baseRequest)
  {
    List<ErrorDetail> errorDetails = new ArrayList();
    
    if ((baseRequest instanceof CognitoGetRequest))
    {
      CognitoGetRequest request = (CognitoGetRequest)baseRequest;
      ErrorDetail errorDetail = null;
      

      if (StringUtils.isBlank(request.getGetRequestValue())) {
        errorDetail = new ErrorDetail();
        errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.VALIDATION_ERROR.getErrorCode());
        errorDetail.setErrorDescription("Parameter invalid/missing. Please provide the correct value for the request.");
        errorDetails.add(errorDetail);
      }
    }
    
    return errorDetails;
  }
  
  public AWSBaseResponse getValidationResponse(AWSBaseRequest baseRequest, List<ErrorDetail> errorList)
  {
    processResponse.createOrCleanMap();
    ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(1L));
    
    if ((baseRequest instanceof CognitoGetRequest)) {
      CognitoResponse cognitoResponse = new CognitoResponse();
      processResponse.setValues("Service Details", " Service Failure!");
      
      cognitoResponse.setServiceStatus(serviceStatus);
      cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      cognitoResponse.setErrorDetails(errorList);
      return cognitoResponse;
    }
    
    return null;
  }
}
