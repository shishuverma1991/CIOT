package com.aricent.ciot.helper;

import java.text.DateFormat;
import java.util.Collection;
import java.util.Date;

public class StringUtils
{
  public StringUtils() {}
  
  public static boolean isBlank(String string)
  {
    boolean flag = false;
    if ((string == null) || (string.length() == 0)) {
      flag = true;
    }
    return flag;
  }
  
  public static String getCurrentDate() {
    DateFormat dateFormat = new java.text.SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
    Date date = new Date();
    return dateFormat.format(date);
  }
  
  public static boolean checkListisNotEmpty(Collection collection)
  {
    boolean flag = false;
    if ((collection == null) || (collection.size() == 0)) {
      flag = true;
    }
    return flag;
  }
  
  public static boolean checkStringsAreEqual(String first, String second) {
    boolean flag = false;
    if (first.equalsIgnoreCase(second)) {
      flag = true;
    }
    return flag;
  }
}
