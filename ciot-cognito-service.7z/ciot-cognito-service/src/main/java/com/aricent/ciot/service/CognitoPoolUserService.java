package com.aricent.ciot.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amazonaws.SdkClientException;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.model.AWSCognitoIdentityProviderException;
import com.amazonaws.services.cognitoidp.model.AdminCreateUserRequest;
import com.amazonaws.services.cognitoidp.model.AdminCreateUserResult;
import com.amazonaws.services.cognitoidp.model.AdminDeleteUserRequest;
import com.amazonaws.services.cognitoidp.model.AdminDeleteUserResult;
import com.amazonaws.services.cognitoidp.model.AdminGetUserRequest;
import com.amazonaws.services.cognitoidp.model.AdminGetUserResult;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AdminResetUserPasswordRequest;
import com.amazonaws.services.cognitoidp.model.AdminResetUserPasswordResult;
import com.amazonaws.services.cognitoidp.model.AdminRespondToAuthChallengeResult;
import com.amazonaws.services.cognitoidp.model.ChallengeNameType;
import com.amazonaws.services.cognitoidp.model.ChangePasswordRequest;
import com.amazonaws.services.cognitoidp.model.ChangePasswordResult;
import com.amazonaws.services.cognitoidp.model.ConfirmForgotPasswordRequest;
import com.amazonaws.services.cognitoidp.model.ConfirmForgotPasswordResult;
import com.amazonaws.services.cognitoidp.model.ForgotPasswordRequest;
import com.amazonaws.services.cognitoidp.model.ForgotPasswordResult;
import com.amazonaws.services.cognitoidp.model.GetUserRequest;
import com.amazonaws.services.cognitoidp.model.GetUserResult;
import com.amazonaws.services.cognitoidp.model.GlobalSignOutRequest;
import com.amazonaws.services.cognitoidp.model.GlobalSignOutResult;
import com.amazonaws.services.cognitoidp.model.InvalidParameterException;
import com.amazonaws.services.cognitoidp.model.NotAuthorizedException;
import com.amazonaws.services.cognitoidp.model.ResourceNotFoundException;
import com.amazonaws.services.cognitoidp.model.UserNotFoundException;
import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.ciot.helper.StringUtils;
import com.aricent.ciot.model.CognitoGetRequest;
import com.aricent.ciot.model.CognitoResponse;
import com.aricent.ciot.model.CognitoUserRequest;
import com.aricent.ciot.model.service.CognitoUserRequestValidator;
import com.aricent.ciot.model.service.ProcessRequest;
import com.aricent.ciot.model.service.ProcessResponse;
import com.aricent.iot.common.model.AWSBaseRequest;
import com.aricent.iot.common.model.ErrorDetail;
import com.aricent.iot.common.model.ServiceStatus;
import com.aricent.iot.common.utils.LogUtil;
import com.aricent.statuscodes.AWSErrorCodes;




@Service
public class CognitoPoolUserService
{
  @Autowired
  private AWSCognitoIdentityGenerator awsCognitoIdentityGenerator;
  @Autowired
  private ProcessResponse processResponse;
  @Autowired
  private ProcessRequest processRequest;
  @Autowired
  private TokenGenerator tokenGenerator;
  
  public CognitoPoolUserService() {}
  
  private CognitoResponse cognitoResponse = null;
  
  public AWSBaseRequest prepareCognitoPoolUserGetRequest(String name, String value) {
    LogUtil.serviceInfo("CognitoPoolUserService", "prepareCognitoPoolUserGetRequest--START");
    
    CognitoGetRequest cognitoGetRequest = new CognitoGetRequest("System", awsCognitoIdentityGenerator.getSpringApplicationName(), StringUtils.getCurrentDate(), value, name);
    LogUtil.serviceInfo("CognitoPoolUserService", "prepareCognitoPoolUserGetRequest--END");
    return cognitoGetRequest;
  }
  
  public AWSBaseRequest prepareCognitoUserRequest(CognitoUserRequest cognitoUserRequest) {
    LogUtil.serviceInfo("CognitoPoolUserService", "prepareCognitoUserRequest--START");
    cognitoUserRequest.setInvokedBy("System");
    cognitoUserRequest.setWebServiceId(awsCognitoIdentityGenerator.getSpringApplicationName());
    cognitoUserRequest.setDate(StringUtils.getCurrentDate());
    LogUtil.serviceInfo("CognitoPoolUserService", "prepareCognitoUserRequest--END");
    return cognitoUserRequest;
  }
  
  public CognitoResponse serveAdminGetUserResult(AWSBaseRequest awsBaseRequest) throws CognitoServiceException {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveAdminGetUserResult--START");
    if ((awsBaseRequest instanceof CognitoGetRequest)) {
      CognitoGetRequest cognitoGetRequest = (CognitoGetRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        AdminGetUserRequest adminGetUserRequest = new AdminGetUserRequest();
        adminGetUserRequest.setUsername(cognitoGetRequest.getGetRequestValue());
        adminGetUserRequest.setUserPoolId(awsCognitoIdentityGenerator.get_cognitoUserpoolId());
        AdminGetUserResult adminGetUser = client.adminGetUser(adminGetUserRequest);
        cognitoResponse = new CognitoResponse();
        BigInteger statusCode = BigInteger.valueOf(adminGetUser.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        processResponse.setValues("User Details", adminGetUser.getUserAttributes());
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveAdminGetUserResult--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveResetUserPassward(AWSBaseRequest awsBaseRequest) throws CognitoServiceException
  {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveResetUserPassward--START");
    if ((awsBaseRequest instanceof CognitoGetRequest)) {
      CognitoGetRequest cognitoGetRequest = (CognitoGetRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        AdminResetUserPasswordRequest adminResetUserPasswordRequest = new AdminResetUserPasswordRequest();
        adminResetUserPasswordRequest.setUsername(cognitoGetRequest.getGetRequestValue());
        adminResetUserPasswordRequest.setUserPoolId(awsCognitoIdentityGenerator.get_cognitoUserpoolId());
        
        AdminResetUserPasswordResult adminResetUserPassword = client.adminResetUserPassword(adminResetUserPasswordRequest);
        
        cognitoResponse = new CognitoResponse();
        
        BigInteger statusCode = BigInteger.valueOf(adminResetUserPassword.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        processResponse.setValues("Service Details", "Password reset. Succesfull!");
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveResetUserPassward--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveTestServices() throws CognitoServiceException {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveTestServices--START");
    try {
      cognitoResponse = new CognitoResponse();
      processResponse.createOrCleanMap();
      processResponse.setValues("Service Details", "Service is Up and running");
      ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(0L));
      cognitoResponse.setServiceStatus(serviceStatus);
      cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
    }
    catch (InvalidParameterException awsexception)
    {
      throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
    }
    catch (ResourceNotFoundException awsexception) {
      throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
    }
    catch (UserNotFoundException awsexception) {
      throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
    }
    catch (NotAuthorizedException notAuthorizedException) {
      throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
    }
    catch (AWSCognitoIdentityProviderException awsexception) {
      throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
    }
    catch (NumberFormatException numberFormatException) {
      throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
    }
    catch (SdkClientException sdkClientException) {
      throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
    }
    catch (NullPointerException nullPointerException) {
      throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
    }
    catch (Exception exc) {
      throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveTestServices--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveDeleteUser(AWSBaseRequest awsBaseRequest) throws CognitoServiceException {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveDeleteUser--START");
    if ((awsBaseRequest instanceof CognitoGetRequest)) {
      CognitoGetRequest cognitoGetRequest = (CognitoGetRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        AdminDeleteUserRequest adminDeleteUserRequest = new AdminDeleteUserRequest();
        adminDeleteUserRequest.setUserPoolId(awsCognitoIdentityGenerator.get_cognitoUserpoolId());
        adminDeleteUserRequest.setUsername(cognitoGetRequest.getGetRequestValue());
        AdminDeleteUserResult admindeleteUser = client.adminDeleteUser(adminDeleteUserRequest);
        BigInteger statusCode = BigInteger.valueOf(admindeleteUser.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        
        cognitoResponse = new CognitoResponse();
        processResponse.setValues("Service Details", "User " + cognitoGetRequest
          .getGetRequestValue() + " deleted. Succesfully!");
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (InvalidParameterException awsexception)
      {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveDeleteUser--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveResgesterUser(AWSBaseRequest awsBaseRequest) throws CognitoServiceException {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveResgesterUser--START");
    if ((awsBaseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest cognitoUserRequest = (CognitoUserRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        
        AdminCreateUserRequest adminCreateUserRequest = processRequest.processUserDetails(cognitoUserRequest);
        
        adminCreateUserRequest.setUserPoolId(awsCognitoIdentityGenerator.get_cognitoUserpoolId());
        AdminCreateUserResult adminCreateUser = client.adminCreateUser(adminCreateUserRequest);
        
        BigInteger statusCode = BigInteger.valueOf(adminCreateUser.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        cognitoResponse = new CognitoResponse();
        processResponse.setValues("Service Details", "User " + adminCreateUser.getUser().getUsername() + " created. Succesfully!");
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveResgesterUser--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveChangeDefaultUserPassword(AWSBaseRequest awsBaseRequest)
    throws CognitoServiceException
  {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveChangeDefaultUserPassword--START");
    
    if ((awsBaseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest cognitoUserRequest = (CognitoUserRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        AdminInitiateAuthResult authResponse = tokenGenerator.getAccessToken(cognitoUserRequest, client);
        
        if (ChallengeNameType.NEW_PASSWORD_REQUIRED.name().equals(authResponse.getChallengeName())) {
          String finalpass = cognitoUserRequest.getFinalPassword().trim();
          cognitoResponse = new CognitoResponse();
          if ((finalpass != null) && (!finalpass.isEmpty()))
          {
            AdminRespondToAuthChallengeResult challengeResponse = tokenGenerator.completeNewPasswordChallenge(cognitoUserRequest, authResponse, client);
            
            BigInteger statusCode = BigInteger.valueOf(challengeResponse.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
            ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
            processResponse.setValues("Service Details", " Password reset. Succesfull!");
            
            cognitoResponse.setServiceStatus(serviceStatus);
            cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
          } else {
            ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(1L));
            processResponse.setValues("Service Details", "Password required to be changed. Please fill the new password field");
            
            cognitoResponse.setServiceStatus(serviceStatus);
            cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
          }
        }
        else {
          String accesstoken = authResponse.getAuthenticationResult().getAccessToken();
          ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
          changePasswordRequest.setPreviousPassword(cognitoUserRequest.getPassword());
          changePasswordRequest.setProposedPassword(cognitoUserRequest.getFinalPassword());
          changePasswordRequest.setAccessToken(accesstoken);
          ChangePasswordResult changePassword = client.changePassword(changePasswordRequest);
          BigInteger statusCode = BigInteger.valueOf(changePassword.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
          ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
          processResponse.setValues("Service Details", "Password reset. Succesfull!");
          cognitoResponse.setServiceStatus(serviceStatus);
          cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
        }
      }
      catch (InvalidParameterException awsexception)
      {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveChangeDefaultUserPassword--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveCodeGenerationOnForgotPassword(AWSBaseRequest awsBaseRequest)
    throws CognitoServiceException
  {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveCodeGenerationOnForgotPassword--START");
    
    if ((awsBaseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest cognitoUserRequest = (CognitoUserRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        
        ForgotPasswordRequest forgotPasswordRequest = new ForgotPasswordRequest().withUsername(cognitoUserRequest.getUserName());
        forgotPasswordRequest.setClientId(awsCognitoIdentityGenerator.get_cognitoClientId());
        ForgotPasswordResult forgotPassword = client.forgotPassword(forgotPasswordRequest);
        cognitoResponse = new CognitoResponse();
        BigInteger statusCode = BigInteger.valueOf(forgotPassword.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        
        processResponse.setValues("Code Delivery Details", forgotPassword.getCodeDeliveryDetails());
        
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveCodeGenerationOnForgotPassword--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveConfirmForgotPassword(AWSBaseRequest awsBaseRequest) throws CognitoServiceException {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveConfirmForgotPassword--START");
    if ((awsBaseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest cognitoUserRequest = (CognitoUserRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        ConfirmForgotPasswordRequest confirmForgotPasswordRequest = new ConfirmForgotPasswordRequest();
        confirmForgotPasswordRequest.setConfirmationCode(cognitoUserRequest.getCode());
        confirmForgotPasswordRequest.setUsername(cognitoUserRequest.getUserName());
        confirmForgotPasswordRequest.setPassword(cognitoUserRequest.getFinalPassword());
        confirmForgotPasswordRequest.setClientId(awsCognitoIdentityGenerator.get_cognitoClientId());
        
        ConfirmForgotPasswordResult confirmForgotPassword = client.confirmForgotPassword(confirmForgotPasswordRequest);
        cognitoResponse = new CognitoResponse();
        
        BigInteger statusCode = BigInteger.valueOf(confirmForgotPassword.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
        ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
        processResponse.setValues("Service Details", "Passsword change Successfull!!");
        
        cognitoResponse.setServiceStatus(serviceStatus);
        cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveConfirmForgotPassword--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveLoginPoolUser(AWSBaseRequest awsBaseRequest, CognitoUserRequestValidator cognitoUserRequestValidator)
    throws CognitoServiceException
  {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveLoginPoolUser--START");
    
    if ((awsBaseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest cognitoUserRequest = (CognitoUserRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        AdminInitiateAuthResult authResponse = tokenGenerator.getAccessToken(cognitoUserRequest, client);
        
        if (ChallengeNameType.NEW_PASSWORD_REQUIRED.name().equals(authResponse.getChallengeName())) {
          List<ErrorDetail> errorDetails = new ArrayList();
          ErrorDetail errorDetail = new ErrorDetail();
          errorDetail.setErrorCode("ERR_COGNITO" + AWSErrorCodes.CHALLENGE_EXCEPTION.getErrorCode());
          errorDetail.setErrorDescription("New Password challenge");
          errorDetails.add(errorDetail);
          
          cognitoResponse = ((CognitoResponse)cognitoUserRequestValidator.getValidationResponse(cognitoUserRequest, errorDetails));
        } else {
          String accesstoken = authResponse.getAuthenticationResult().getAccessToken();
          GetUserRequest getUserRequest = new GetUserRequest();
          getUserRequest.setAccessToken(accesstoken);
          GetUserResult user = client.getUser(getUserRequest);
          BigInteger statusCode = BigInteger.valueOf(user.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
          ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
          cognitoResponse = new CognitoResponse();
          processResponse.setValues("userDetails", user);
          processResponse.setValues("accesstoken", accesstoken);
          cognitoResponse.setServiceStatus(serviceStatus);
          cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
        }
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    
    LogUtil.serviceInfo("CognitoPoolUserService", "serveLoginPoolUser--END");
    return cognitoResponse;
  }
  
  public CognitoResponse serveLogoutPoolUser(AWSBaseRequest awsBaseRequest, CognitoUserRequestValidator cognitoUserRequestValidator)
    throws CognitoServiceException
  {
    LogUtil.serviceInfo("CognitoPoolUserService", "serveLogoutPoolUser--START");
    if ((awsBaseRequest instanceof CognitoUserRequest)) {
      CognitoUserRequest cognitoUserRequest = (CognitoUserRequest)awsBaseRequest;
      try {
        processResponse.createOrCleanMap();
        AWSCognitoIdentityProvider client = awsCognitoIdentityGenerator.getawsclient();
        GetUserRequest getUserRequest = new GetUserRequest();
        getUserRequest.setAccessToken(cognitoUserRequest.getToken());
        GetUserResult user = client.getUser(getUserRequest);
        
        List<ErrorDetail> errorDetails = cognitoUserRequestValidator.validateUserName(cognitoUserRequest, user
          .getUsername());
        if (errorDetails.size() > 0)
        {
          cognitoResponse = ((CognitoResponse)cognitoUserRequestValidator.getValidationResponse(cognitoUserRequest, errorDetails));
        } else {
          GlobalSignOutRequest globalSignOutRequest = new GlobalSignOutRequest();
          globalSignOutRequest.setAccessToken(cognitoUserRequest.getToken());
          GlobalSignOutResult globalSignOut = client.globalSignOut(globalSignOutRequest);
          BigInteger statusCode = BigInteger.valueOf(globalSignOut.getSdkHttpMetadata().getHttpStatusCode() == 200 ? 0L : 2L);
          ServiceStatus serviceStatus = processResponse.getServiceStatus(statusCode);
          cognitoResponse = new CognitoResponse();
          processResponse.setValues("Service Details", "user " + cognitoUserRequest
            .getUserName() + " is Loged out succesfully!!");
          cognitoResponse.setServiceStatus(serviceStatus);
          cognitoResponse.setAwsResponseObject(processResponse.getResponseMap());
        }
      }
      catch (InvalidParameterException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.INVALID_PARAMETER_EXCEPTION.getErrorCode());
      }
      catch (ResourceNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.RESOURCE_NOT_FOUND.getErrorCode());
      }
      catch (UserNotFoundException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.USER_NOT_FOUND.getErrorCode());
      }
      catch (NotAuthorizedException notAuthorizedException) {
        throw new CognitoServiceException(notAuthorizedException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NOT_AUTHORIZED_USER.getErrorCode());
      }
      catch (AWSCognitoIdentityProviderException awsexception) {
        throw new CognitoServiceException(awsexception, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.COGNITO_IDENTITY_PROVIDER.getErrorCode());
      }
      catch (NumberFormatException numberFormatException) {
        throw new CognitoServiceException(numberFormatException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NUMBER_FORMAT.getErrorCode());
      }
      catch (SdkClientException sdkClientException) {
        throw new CognitoServiceException(sdkClientException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.SDK_CLIENT_EXCEPTION.getErrorCode());
      }
      catch (NullPointerException nullPointerException) {
        throw new CognitoServiceException(nullPointerException, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.NULL_VALUE_EXCEPTION.getErrorCode());
      }
      catch (Exception exc) {
        throw new CognitoServiceException(exc, "Error Occurred", "ERR_COGNITO" + AWSErrorCodes.EXCEPTION.getErrorCode());
      }
    }
    LogUtil.serviceInfo("CognitoPoolUserService", "serveLogoutPoolUser--END");
    return cognitoResponse;
  }
}
