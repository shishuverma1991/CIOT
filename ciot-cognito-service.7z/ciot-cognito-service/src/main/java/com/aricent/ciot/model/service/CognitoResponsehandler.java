package com.aricent.ciot.model.service;

import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.ciot.model.CognitoResponse;
import com.aricent.iot.common.exception.AWSResponseHandler;
import com.aricent.iot.common.model.AWSBaseResponse;
import com.aricent.iot.common.model.ErrorDetail;
import com.aricent.iot.common.model.ServiceStatus;
import java.math.BigInteger;
import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;

@org.springframework.stereotype.Service
public class CognitoResponsehandler implements AWSResponseHandler
{
  @Autowired
  private ProcessResponse processResponse;
  
  public CognitoResponsehandler() {}
  
  public AWSBaseResponse handleResponse(AWSBaseResponse awsBaseResponse, Exception exception)
  {
    CognitoServiceException cognitoServiceException = (CognitoServiceException)exception;
    ServiceStatus serviceStatus = processResponse.getServiceStatus(BigInteger.valueOf(2L));
    
    if ((awsBaseResponse instanceof CognitoResponse)) {
      CognitoResponse cognitoResponse = (CognitoResponse)awsBaseResponse;
      cognitoResponse.setServiceStatus(serviceStatus);
      ErrorDetail errorDetail = new ErrorDetail(cognitoServiceException.getErrorCode(), exception.getMessage());
      cognitoResponse.setErrorDetails(Arrays.asList(new ErrorDetail[] { errorDetail }));
      return cognitoResponse;
    }
    return null;
  }
  



  public AWSBaseResponse setInvalidResponse(AWSBaseResponse awsBaseResponse)
  {
    return null;
  }
}
