package com.aricent.ciot.exception;

import com.aricent.iot.common.exception.AWSBaseException;



public class CognitoServiceException
  extends AWSBaseException
{
  private static final long serialVersionUID = 1L;
  
  public CognitoServiceException(String message)
  {
    super(message);
  }
  
  public CognitoServiceException(Throwable cause) {
    super(cause);
  }
  




  public CognitoServiceException(String message, String errorCode)
  {
    super(message, errorCode);
  }
  






  public CognitoServiceException(Throwable cause, String message, String errorCode)
  {
    super(cause, message, errorCode);
  }
}
