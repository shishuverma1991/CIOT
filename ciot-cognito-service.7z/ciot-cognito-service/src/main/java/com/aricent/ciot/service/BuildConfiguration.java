package com.aricent.ciot.service;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.iot.common.utils.LogUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;









@Service
public class BuildConfiguration
{
  @Value("${aws.client.proxyhost}")
  private String _proxyHost;
  @Value("${aws.client.proxyenabled}")
  private String _proxyenabled;
  @Value("${aws.client.proxyport}")
  private String _proxyPort;
  private ClientConfiguration configuration = null;
  


  public BuildConfiguration() {}
  

  public ClientConfiguration getClientConfiguration()
    throws CognitoServiceException
  {
    LogUtil.info("BuildConfiguration", "getClientConfiguration--START");
    if (configuration == null)
    {
      if ("true".equalsIgnoreCase(_proxyenabled.trim())) {
        configuration = new ClientConfiguration();
        configuration.setProtocol(Protocol.HTTPS);
        configuration.setProxyHost(_proxyHost);
        configuration.setProxyPort(Integer.valueOf(_proxyPort).intValue());
      } else if ("false".equalsIgnoreCase(_proxyenabled.trim())) {
        configuration = new ClientConfiguration();
      }
    }
    LogUtil.info("BuildConfiguration", "getClientConfiguration--END");
    return configuration;
  }
}
