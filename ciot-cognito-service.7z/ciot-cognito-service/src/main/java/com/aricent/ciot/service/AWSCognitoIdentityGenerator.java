package com.aricent.ciot.service;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.aricent.ciot.exception.CognitoServiceException;
import com.aricent.iot.common.utils.LogUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

















@Service
public class AWSCognitoIdentityGenerator
{
  @Value("${spring.application.name}")
  public String springApplicationName;
  @Value("${aws.accesskey}")
  public String awsaccesskey;
  @Value("${aws.secretkey}")
  public String awssecretkey;
  @Value("${AWSCognito.config.region}")
  private String awsregion;
  @Value("${AWSCognito.clientid}")
  private String _cognitoClientId;
  @Value("${AWSCognito.userpoolid}")
  private String _cognitoUserpoolId;
  @Autowired
  private BuildConfiguration buildConfiguration;
  
  public AWSCognitoIdentityGenerator() {}
  
  public AWSCognitoIdentityProvider getawsclient()
    throws CognitoServiceException
  {
    LogUtil.info("AWSCognitoIdentityProvider", "getawsclient--START");
    ClientConfiguration configuration = buildConfiguration.getClientConfiguration();
    BasicAWSCredentials awsCreds = new BasicAWSCredentials(awsaccesskey, awssecretkey);
    AWSCognitoIdentityProvider client = (AWSCognitoIdentityProvider)((AWSCognitoIdentityProviderClientBuilder)((AWSCognitoIdentityProviderClientBuilder)((AWSCognitoIdentityProviderClientBuilder)AWSCognitoIdentityProviderClientBuilder.standard().withClientConfiguration(configuration)).withRegion(awsregion)).withCredentials(new AWSStaticCredentialsProvider(awsCreds))).build();
    LogUtil.info("AWSCognitoIdentityProvider", "getawsclient--END");
    return client;
  }
  
  public String get_cognitoClientId() {
    return _cognitoClientId;
  }
  
  public String get_cognitoUserpoolId() {
    return _cognitoUserpoolId;
  }
  
  public String getSpringApplicationName() {
    return springApplicationName;
  }
}
