/**
 * 
 */
package com.aricent.iot.common.validator;

import java.util.List;

import com.aricent.iot.common.model.AWSBaseRequest;
import com.aricent.iot.common.model.AWSBaseResponse;
import com.aricent.iot.common.model.ErrorDetail;

/**
 * @author gur50508
 *
 */
public interface AWSValidator {

	
	/**
	 * This method is used to validate the incoming request.
	 * @param baseRequest
	 * @return list of ErrorDetail
	 */
	List<ErrorDetail> validate(AWSBaseRequest baseRequest);
	
	
	/**
	 * This method is used to generate the response in case of validation failure.
	 * @param baseRequest as AWSBaseRequest
	 * @param errorList as List of ErrrorDetail
	 * @return AWSBaseResponse
	 */
	AWSBaseResponse getValidationResponse(AWSBaseRequest baseRequest, List<ErrorDetail> errorList);
}
