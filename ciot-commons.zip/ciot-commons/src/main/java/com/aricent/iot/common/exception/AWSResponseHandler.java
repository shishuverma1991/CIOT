package com.aricent.iot.common.exception;

import com.aricent.iot.common.model.AWSBaseResponse;

/**
 * 
 * @author gur50508
 *
 */
public interface AWSResponseHandler {

	
	/**
	 * 
	 * @param AWSBaseResponse as {@link AWSBaseResponse}
	 * @param exception as {@link Exception}
	 * @return {@link AWSBaseResponse}
	 */
	AWSBaseResponse handleResponse(final AWSBaseResponse awsBaseResponse, 
			final Exception exception);
	
	/**
	 * 
	 * @param awsBaseRequest as {@link AWSBaseResponse}
	 * @return {@link AWSBaseResponse}
	 */
	AWSBaseResponse setInvalidResponse(final AWSBaseResponse awsBaseResponse);

}
