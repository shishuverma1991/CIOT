package com.aricent.iot.common.exception;


/**
 * 
 * @author gur50508
 *
 */
public class AWSBaseException extends Exception{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String message = null;
	
	private String errorCode=null;
	
	public AWSBaseException() {
		super();
	}
	
	
	/**
	 * 
	 * @param message
	 */
	public AWSBaseException(String message) {
		super(message);
		this.message = message;
	}
	
	
	/**
	 * 
	 * @param message
	 * @param errorCode
	 */
	public AWSBaseException(String message, String errorCode) {
		super(message);
		this.message = message;
		this.errorCode = errorCode;
	}
	
	/**
	 * 
	 * @param cause
	 */
	public AWSBaseException(Throwable cause) {
		super(cause);
	}
	
	
	/**
	 * 
	 * @param cause
	 * @param message
	 * @param errorCode
	 */
	public AWSBaseException(Throwable cause, String message, String errorCode) {
		super(message,cause);
		this.message = message;
		this.errorCode = errorCode;
	}
	
	/**
	 * 
	 * @return errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	
	/**
	 * 
	 * @param errorCode
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AWSBaseException [message=" + message + ", errorCode=" + errorCode + "]";
	}
	
	
}
