package com.aricent.iot.common.model;

import java.util.List;

/**
 * 
 * @author gur50508
 *
 */
public class ValidationErrors {

	private List<ErrorDetail> errorList;
	
	public ValidationErrors() {
		
	}

	/**
	 * @return the errorList
	 */
	public List<ErrorDetail> getErrorList() {
		return errorList;
	}

	/**
	 * @param errorList the errorList to set
	 */
	public void setErrorList(List<ErrorDetail> errorList) {
		this.errorList = errorList;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ValidationErrors [errorList=" + errorList + "]";
	}
	
	

}
