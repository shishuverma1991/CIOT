/**
 * 
 */
package com.aricent.iot.common.utils;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author gur50508
 *
 */
public class Utility {


	/** Object mapper for JSON marshaling */
	private static ObjectMapper MAPPER = new ObjectMapper();

	
	/**
	 * Marshal an object to a byte array.
	 * @param object
	 * @return
	 * @throws CIoTException
	 */
	public static String getJsonFromObject(final Object object) {

		String jsonString = "";
		try {
			jsonString = MAPPER.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return jsonString;
	}
	
	/**
	 * 
	 * @param oldOject
	 * @return
	 */
	public static Object deepClone(Object oldOject) {
		
		if(null != oldOject) {
			ObjectOutputStream outputStream = null;
			ObjectInputStream inputStream = null;
			ByteArrayOutputStream arrayOutputStream = null;
			ByteArrayInputStream arrayInputStream = null;
			
			try {
				arrayOutputStream = new ByteArrayOutputStream();
				outputStream = new ObjectOutputStream(arrayOutputStream);
				
				outputStream.writeObject(oldOject);
				outputStream.flush();
				
				arrayInputStream = new ByteArrayInputStream(arrayOutputStream.toByteArray());
				inputStream = new ObjectInputStream(arrayInputStream);
						
				return inputStream.readObject();
				
			} catch(Exception exc) {
				return null;
			}
		} else {
			return oldOject;
		}
		
	}

}
