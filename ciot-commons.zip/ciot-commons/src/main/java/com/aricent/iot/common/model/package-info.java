/**
 * 
 */
/**
 * @author gur50508
 *
 */
package com.aricent.iot.common.model;