/**
 * 
 */
package com.aricent.iot.common.model;

import java.io.Serializable;

/**
 * 
 * @author gur50508
 *
 */
public abstract class AWSBaseResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ServiceStatus serviceStatus;

	/**
	 * @return the serviceStatus
	 */
	public ServiceStatus getServiceStatus() {
		return serviceStatus;
	}

	/**
	 * @param serviceStatus the serviceStatus to set
	 */
	public void setServiceStatus(ServiceStatus serviceStatus) {
		this.serviceStatus = serviceStatus;
	}
	
	
}
