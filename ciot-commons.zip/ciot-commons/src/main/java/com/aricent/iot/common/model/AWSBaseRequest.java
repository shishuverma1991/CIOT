/**
 * 
 */
package com.aricent.iot.common.model;

import java.io.Serializable;

/**
 * 
 * @author gur50508
 *
 */
public abstract class AWSBaseRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String invokedBy;
	private String webServiceId;
	private String date;
	
	/**
	 * 
	 */
	public AWSBaseRequest() {
		super();
	}
	
	/**
	 * @param invokedBy
	 * @param webServiceId
	 * @param date
	 */
	public AWSBaseRequest(String invokedBy, String webServiceId, String date) {
		super();
		this.invokedBy = invokedBy;
		this.webServiceId = webServiceId;
		this.date = date;
	}

	/**
	 * @return the invokedBy
	 */
	public String getInvokedBy() {
		return invokedBy;
	}

	/**
	 * @param invokedBy the invokedBy to set
	 */
	public void setInvokedBy(String invokedBy) {
		this.invokedBy = invokedBy;
	}

	/**
	 * @return the webServiceId
	 */
	public String getWebServiceId() {
		return webServiceId;
	}

	/**
	 * @param webServiceId the webServiceId to set
	 */
	public void setWebServiceId(String webServiceId) {
		this.webServiceId = webServiceId;
	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}
	
	

}
