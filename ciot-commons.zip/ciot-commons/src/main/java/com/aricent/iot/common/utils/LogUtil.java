package com.aricent.iot.common.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.log4j.Logger;



public class LogUtil {



	public static final Logger LOG = Logger.getLogger(LogUtil.class);

	private static final Logger ENDPOINT_LOGGER = Logger.getLogger("EndPointLog");

	private static final Logger ERROR_LOGGER = Logger.getLogger("ErrorLog");

	private static final Logger SERVICE_LOGGER = Logger.getLogger("ServiceLog");
	
	private static final Logger INFO_LOGGER = Logger.getLogger("InfoLog");

	private static DateFormat df = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");

	private static final String LOG_COLUMN_SEPARATOR = " ~~ ";

	private static final String STACK_TRACE_NEW_LINE_SEPARATOR = "@@";


	
	/**
	 * 
	 * @param className
	 * @param method
	 * @param message
	 */
	public static void info(String className, String method, String message) {
		LOG.info("[" + checkNullable(className) + "/" + checkNullable(method)
				+ "]" + message);
	}

	/**
	 * 
	 * @param className
	 * @param method
	 * @param message
	 */
	public static void warn(String className, String method, String message) {
		LOG.warn("[" + checkNullable(className) + "/" + checkNullable(method)
				+ "]" + message);
	}

	
	/**
	 * 
	 * @param className
	 * @param method
	 * @param message
	 */
	public static void debug(String className, String method, String message) {
		LOG.debug("[" + checkNullable(className) + "/" + checkNullable(method)
				+ "]" + message);
	}

	
	/**
	 * 
	 * @param className
	 * @param method
	 * @param message
	 * @param stackTrace
	 */
	public static void error(String className, String method, String message,
			String stackTrace) {
		String errorKey = "message = "
				+ checkNullable(message)
				+ LOG_COLUMN_SEPARATOR
				+ "className ="
				+ checkNullable(className)
				+ LOG_COLUMN_SEPARATOR
				+ "method = "
				+ checkNullable(method)
				+ LOG_COLUMN_SEPARATOR
				+ "stackTrace = "
				+ checkNullable(stackTrace.replaceAll("(\\r|\\n)",
						STACK_TRACE_NEW_LINE_SEPARATOR)) + "}";
		LOG.error(errorKey);
	}

	/**
	 * 
	 * @param value
	 * @return
	 */
	public static String checkNullable(String value) {
		return value != null && !value.trim().equals("") ? value.trim() : "NA";
	}

	/**
	 * customized logger info for error log
	 * 
	 * @param className as String
	 * @param method as String
	 * @param stackTrace as String
	 */
	public static void errorInfo(String className, String method, Throwable throwable) {
		if (LogUtil.logEnabled()) {

			String errorMessage = new StringBuilder().append("ClassName = ").append(checkNullable(className))
					.append(LOG_COLUMN_SEPARATOR).append("Method = ").append(checkNullable(method))
					.append(LOG_COLUMN_SEPARATOR).append("StackTrace = ")
					.append(checkNullable(
							getStackeTrace(throwable).replaceAll("(\\r|\\n)", STACK_TRACE_NEW_LINE_SEPARATOR)))
					.toString();

			ERROR_LOGGER.error(errorMessage);
		}

	}

	/**
	 * Customized logger info for printing control flow of service layer.
	 * 
	 * @param className as String
	 * @param method as String
	 * @param message as String
	 */
	public static void serviceInfo(String className, String method,
			String message) {
		if (LogUtil.logEnabled()) {
			
			String servicePointMessage = new StringBuilder().append("ClassName = ").append(checkNullable(className))
					.append(LOG_COLUMN_SEPARATOR).append("Method = ").append(checkNullable(method))
					.append(LOG_COLUMN_SEPARATOR).append("Message = ").append(checkNullable(message)).toString();
			
			SERVICE_LOGGER.info(servicePointMessage);
		}

	}
	
	/**
	 * 
	 * @param className
	 * @param method
	 */
	public static void serviceInfo(String className, String method) {
		serviceInfo(className, method, "");
	}

	/**
	 * Customized logger info for printing control flow of controller layer.
	 * 
	 * @param className as String
	 * @param method as String
	 * @param message as String
	 */

	public static void endPointInfo(String className, String method,
			String message) {
		if (LogUtil.logEnabled()) {
			
			String endPointMessage = new StringBuilder().append("ClassName = ").append(checkNullable(className))
					.append(LOG_COLUMN_SEPARATOR).append("Method = ").append(checkNullable(method))
					.append(LOG_COLUMN_SEPARATOR).append("Message = ").append(checkNullable(message)).toString();
			
			ENDPOINT_LOGGER.info(endPointMessage);
		}

	}
	
	/**
	 * 
	 * @param className
	 * @param method
	 */
	public static void endPointInfo(String className, String method) {
		endPointInfo(className, method, "");
	}
	
	/**
	 * 
	 * @param className
	 * @param method
	 */
	public static void info(String className, String message) {
		if (LogUtil.logEnabled()) {
			
			String endPointMessage = new StringBuilder().append("ClassName = ").append(checkNullable(className))
					.append(LOG_COLUMN_SEPARATOR).append("Message = ").append(checkNullable(message)).toString();
			
			INFO_LOGGER.info(endPointMessage);
		}
	}

	/**
	 * Used to whether logging is enabled or not
	 * 
	 * @return boolean
	 */
	public static boolean logEnabled() {
		return true;
	}

	/**
	 * 
	 * @return
	 */
	public static String getDate() {
		Date today = Calendar.getInstance().getTime();
		String reportDate = df.format(today);
		return reportDate;
	}
	
	/**
	 * 
	 * @param throwable
	 * @return
	 */
	public static String getStackeTrace(Throwable throwable) {
		
		StringWriter sw = new StringWriter();
    	PrintWriter pw = new PrintWriter(sw);
    	throwable.printStackTrace(pw);
    	return sw.toString();
	}


}
